# Pingu Party

Implementation of the Pingu Party card game, originally by Reiner Knizia.

This software was developped as an assignment during the 2018/10 university year at the CERI, University of Avignon (France), by the following students:
* Author 1
* Author 2
* Author 3

It can be used by a human to play against artificial agents, or against distant players through a network. 


## Organization
The source code is organized as follows... 
<list the folders/packages, explain their role>


## Installation
Here is the procedure to install this software :
1. Do this
2. Do that
3. etc.


## Use
In order to use the software, you must...
1. Do this
2. Do that
3. etc.

The project wiki (put a hyperlink) contains detailed instructions regarding how to use the game.


## Dependencies
The project relies on the following librarie:
* xxxxx : this library was used to...
* yyyyy: ...

## References
During development, we use the following bibliographic resources:
* Webpage x: it explains the rules of the game.
* Book xxxx: it describes how to write an artifical agent in Java.
* etc.
* 


