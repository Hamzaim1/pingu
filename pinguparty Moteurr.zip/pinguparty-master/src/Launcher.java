
/**
 * This class is used to launch the game.
 * 
 * @author Author 1
 * @author Author 2
 * @author Author 3
 */
 public class Launcher
{	
	
	/**
	 * Launches the game.
	 * 
	 * @param args
	 * 		Not used here.
	 */
	public static void main(String[] args)
	{	//TODO to be completeds
	}
}
