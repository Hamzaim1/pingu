package engine.game;


public class Test {

    public static void main(String[] args)
    {
        Player user = new Player(0);

        user.createGame();


    }
}