package engine.game;

import network.Server;

import java.util.*;

public class Player
{
    /** player's number in the current game */
    private int idPlayer;
    /** determines whether the player is played by an AI or a human */
    private boolean isHuman;

    /** determines whether the player can still play in the current round */
    private boolean ableToPlay = true;

    /** player's hand */
    private Card[] hand = new Card[14];
    /** number of cards currently in hand */
    private int nbCards = 0;
    /** contain cards' number of each color that the player has in hand */
    protected Map<Color, Integer> colorsCounter;

    /** player's score for the current game */
    private int score = 0;
    /** number of green cards played */
    private int nbGreenCardsPlayed = 0;


    /**
     * create new AI-based Player
     * @param idPlayer id of player
     */
    public Player(int idPlayer)
    {
    	//set player's ID
        this.idPlayer = idPlayer;

        // by default: player is AI-based
        this.isHuman = false;

        // create counter of colors in hand
        this.colorsCounter = new HashMap<>();
        this.colorsCounter.put(Color.Blue, 0);
        this.colorsCounter.put(Color.Green, 0);
        this.colorsCounter.put(Color.Purple, 0);
        this.colorsCounter.put(Color.Red, 0);
        this.colorsCounter.put(Color.Yellow, 0);
    }


    /**
     * create new player
     * @param idPlayer id of player
     * @param isHuman  whether the player is human or AI-based
     */
    public Player(int idPlayer, boolean isHuman)
    {
        // call the default constructor
        this(idPlayer);
        // set AI
        this.isHuman = isHuman;
    }

    /**
     * plays a card on a position on the board
     * @return the card to play and its position on the board; null if skip turn
     */
    Map<String, Object> play(Card[][] board)
    {
        // if human: prompt which card to play; otherwise, play a random card
        return this.isHuman ? this.promptMove(board)
                            : this.playRandomCard(board);
    }


    /**
     * asks the user to play a card while the move isn't valid
     * @return the card to play and its position on the board; null if skip turn
     */
    private Map<String, Object> promptMove(Card[][] board)
    {
        // map containing the card to play and the coordinates on the board
        Map<String, Object> move = new HashMap<>();

        // prompt user the move to play while the move's not valid
        do
        {
            // display cards currently in hand
            this.displayPlayerHand();

            // add card to map
            promptCard(move);

            // if player skips his turn
            if (move.get("card") == null)
                return null;

            // add floor to map
            promptFloor(move);

            // add position to map
            promptPosition(move);
        }
        while (!Round.isCardPlayable(board, move));

        // delete card to play from player's hand
        if (!this.deleteCardFromHand((Card)move.get("card")))
        {
            System.out.println("couldn't delete card");
            // if couldn't delete card: skip turn
            return null;
        }

        // return move to play
        return move;
    }


    /**
     * prompts card to play to player and adds it to the given map
     * @param move the hashmap to populate with the card to play
     */
    protected void promptCard(Map<String, Object> move)
    {
        do
        {
            // prompt move to player
            System.out.print("Card to play (R, P, Y, G, B; N for none): ");

            switch (Game.scan.nextLine())
            {
                case "R":
                    // if no card of this color in hand
                    if (this.colorsCounter.get(Color.Red) <= 0)
                        System.out.println("no red cards remaining");
                    else
                        move.put("card", new Card(Color.Red));
                    break;
                case "P":
                    if (this.colorsCounter.get(Color.Purple) <= 0)
                        System.out.println("no purple cards remaining");
                    else
                        move.put("card", new Card(Color.Purple));
                    break;
                case "Y":
                    if (this.colorsCounter.get(Color.Yellow) <= 0)
                        System.out.println("no yellow cards remaining");
                    else
                        move.put("card", new Card(Color.Yellow));
                    break;
                case "G":
                    if (this.colorsCounter.get(Color.Green) <= 0)
                        System.out.println("no green cards remaining");
                    else
                        move.put("card", new Card(Color.Green));
                    break;
                case "B":
                    if (this.colorsCounter.get(Color.Blue) <= 0)
                        System.out.println("no blue cards remaining");
                    else
                        move.put("card", new Card(Color.Blue));
                    break;
                case "N":
                    move.put("card", null);
            }
        }
        while (move.get("card") == null);
    }


    /**
     * prompts floor to play the card on to player and adds it to the given map
     * @param move the hashmap to populate
     */
    protected void promptFloor(Map<String, Object> move)
    {
        // user input
        String input;

        // prompt floor
        do
        {
            System.out.print("Floor to play the card on:");
            // get floor from user input
            input = Game.scan.nextLine();
        }
        while (!Game.isInteger(input));

        // add floor to map
        move.put("floor", Integer.parseInt(input));
    }


    /**
     * prompts position to the player and adds it to the given map
     * @param move the hashmap to populate
     */
    protected void promptPosition(Map<String, Object> move)
    {
        // user input
        String input;

        do
        {
            // prompt position
            System.out.print("Position on the floor:");
            // get position from user input
            input = Game.scan.nextLine();
        }
        while (!Game.isInteger(input));

        // add position to map
        move.put("position", Integer.parseInt(input));
    }


    /**
     * displays player's hand
     */
    protected void displayPlayerHand()
    {
        System.out.println("Playable cards in hand:");
        // display number of cards in the cards' color
        System.out.println("    " +
                Color.ANSI_BLUE + colorsCounter.get(Color.Blue) +
                " blue cards");

        System.out.println("    " +
                Color.ANSI_YELLOW + colorsCounter.get(Color.Yellow) +
                " yellow cards");

        System.out.println("    " +
                Color.ANSI_PURPLE + colorsCounter.get(Color.Purple) +
                " purple cards");

        System.out.println("    " +
                Color.ANSI_GREEN + colorsCounter.get(Color.Green) +
                " green cards");

        System.out.println("    " +
                Color.ANSI_RED + colorsCounter.get(Color.Red) +
                " red cards" + Color.ANSI_RESET);
    }


    /**
     * plays a card at the first valid position
     * @return the card to play and its position on the board; null if skip turn
     */
    private Map<String, Object> playRandomCard(Card[][] board)
    {
        // map to return
        Map<String, Object> move = new HashMap<>();

        // for each card in hand
        for (int card = 0; card < this.nbCards; card++)
        {
            // for each floor on board
            for (int floor = 0; floor < board.length; floor++)
            {
                // for each slot in floor
                for (int slot = 0; slot < board[floor].length; slot++)
                {
                    // if card playable
                    if (Round.isCardPlayable(board, this.hand[card], floor, slot))
                    {
                        // fill map to return
                        move.put("card", this.hand[card]);
                        move.put("floor", floor);
                        move.put("position", slot);

                        // delete card from player's hand
                        if (!this.deleteCardFromHand(this.hand[card]))
                        {
                            System.out.println("couldn't delete card");
                            // if couldn't delete card: skip turn
                            return null;
                        }

                        //return move to play
                        return move;
                    }
                }
            }
        }

        // if no cards playable: return null
        return null;
    }


    /**
     * adds a card to player's hand
     * @param c the card to add
     */
    void addCardToHand(Card c)
    {
        // if hand not full
        if (this.nbCards < 14)
        {
            // add card at the end of the hand and increment counter
            this.hand[this.nbCards++] = c;
            // update color's counter
            this.colorsCounter.put(
                    c.getColor(),
                    colorsCounter.get(c.getColor()) + 1);
        }
    }


    /**
     * deletes a card from player's hand with the same color as given card
     * @param c the card used to get the color of the card to delete
     * @return true if a card was deleted, false otherwise
     */
    protected boolean deleteCardFromHand(Card c)
    {
        // if no cards in hand: return false
        if (this.nbCards == 0)
            return false;

        // counter to iterate through hand
        int i = nbCards - 1;
        // looking for a card with the same color to delete it from hand
        while (i >= 0 && this.hand[i].getColor() != c.getColor())
            --i;

        // if no card matching the color of the given card was found: do nothing
        if (i < 0)
            return false;

        // update cards counter
        --this.nbCards;
        //update green cards counter
        if (c.getColor() == Color.Green)
            ++this.nbGreenCardsPlayed;
        // update colors' counter
        this.colorsCounter.put(
                c.getColor(),
                colorsCounter.get(c.getColor()) - 1);

        // put all cards at the beginning of the array
        for (; i < nbCards; i++)
            this.hand[i] = this.hand[i + 1];

        // delete last card
        this.hand[this.nbCards] = null;

        return true;
    }


    /**
     * create a new game
     */
    public void createGame()
    {
        new Game(this);
    }


    public void createOnlineGame()
    {
        new Server(this);
    }


    /**
     * recalculate score at the end of a round
     */
    void calculateNewScore()
    {
        this.score += this.nbCards;
    }


    /**
     * resets attributes in order to play a new round (hand, etc)
     */
    void resetPlayerNewRound()
    {
        // give the player back the ability to play
        this.ableToPlay = true;

        // empty hand
        for (int i = 0; i < 14; i++)
            this.hand[i] = null;
        // reset cards counter
        this.nbCards = 0;
    }


    /**
     * resets attributes in order to play a new game (score, etc)
     */
    void resetPlayerNewGame()
    {
        // give the player back the ability to play
        this.ableToPlay = true;

        // empty hand
        for (int i = 0; i < 14; i++)
            this.hand[i] = null;
        // reset cards counter
        this.nbCards = 0;
        // reset score
        this.score = 0;
    }


    /**
     * TODO: complete toString
     * @return string representation of the current player
     */
    public String toString()
    {
        return "Local player; ID = " + idPlayer + "; human: " + isHuman;
    }


    public int getIdPlayer()
    {
        return idPlayer;
    }

    int getScore()
    {
        return score;
    }

    void setScore(int score)
    {
        this.score = score;
    }

    public boolean isHuman()
    {
        return isHuman;
    }

    boolean isAbleToPlay()
    {
        return ableToPlay;
    }

    void setAbleToPlay(boolean ableToPlay)
    {
        this.ableToPlay = ableToPlay;
    }

    int getNbGreenCardsPlayed()
    {
        return nbGreenCardsPlayed;
    }
}