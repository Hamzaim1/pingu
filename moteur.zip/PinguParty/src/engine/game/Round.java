package engine.game;

import java.util.*;

public class Round
{

    /** ID of the round in the current game */
    private int roundNumber;

    /** list of players */
    private ArrayList<Player> players;
    /** number of players */
    private int nbPlayers;

    /** list of cards */
    private ArrayList<Card> cardsDeck;

    /** board */
    protected Card[][] board;
    /** number of floors on the board */
    protected int nbFloors;

    /** determines whether the round is finished or not; default value: false */
    private boolean isFinished = false;
    /** number of players who skipped their turn and cannot play this round */
    private int skips = 0;


    /**
     * initializes attributes, then starts offline game from prompt
     * @param roundNumber number of the round into the game (first, second...)
     * @param players list of players
     */
    protected Round(int roundNumber, ArrayList<Player> players)
    {
        // initialises round
        initRound(roundNumber, players);

        // play round
        this.playRoundFromPrompt();
    }


    /**
     * initialises round's attributes
     * @param roundNumber number of the round into the game (first, second...)
     * @param players list of players
     */
    private void initRound(int roundNumber, ArrayList<Player> players)
    {
        // removes all null elements from players list
        for (int i = 0; i < players.size(); i++)
            if (players.get(i) == null)
            {
                players.remove(i);
                // decrease counter to avoid skipping elements
                --i;
            }

        // set round number
        this.roundNumber = roundNumber;

        // set players list
        this.players = players;
        // set number of players
        this.nbPlayers = players.size();

        // initialize new list of cards (max: 36 cards)
        this.cardsDeck = new ArrayList<>(36);

        // initialize board
        this.initBoard();
    }


    /**
     * initializes board and creates pyramid
     * 7 floors in 2 players, 8 floors if more
     */
    private void initBoard()
    {
        // 7 floors to create in the pyramid if 2 players, 8 otherwise
        this.nbFloors = this.nbPlayers == 2 ? 7 : 8;

        // initialize board
        this.board = new Card[nbFloors][];

        // create pyramid: 7/8 floors with 7/8 to 1 slots, in decreasing order
        for (int i = 0; i < nbFloors; i++)
            // initialize each floor
            this.board[i] = new Card[nbFloors - i];
    }


    /**
     * starts and plays round
     */
    private void playRoundFromPrompt()
    {
        // reset players
        for (Player player : players)
            player.resetPlayerNewRound();

        // print round number
        System.out.println("Round " + (this.roundNumber + 1));

        // create cards
        this.createCards();
        // distribute cards to players
        this.distributeCards();

        // player who has to play
        int currentPlayerIndex = 0;

        // playing loop
        while (!this.isFinished)
        {
            // if player not eliminated
            if (this.players.get(currentPlayerIndex).isAbleToPlay())
            {
                // display current board
                displayBoard();

                // make the player play
                this.play(currentPlayerIndex);

                // round finished if board full or all players eliminated
                this.isFinished = isBoardFull() || this.skips == this.nbPlayers;
            }

            // update ID of next player
            currentPlayerIndex = (currentPlayerIndex + 1) % this.nbPlayers;
        }

        // update players' scores
        for (Player p : this.players)
            p.calculateNewScore();
    }


    /**
     * creates cards deck then shuffles it
     */
    private void createCards()
    {
        // create 36 cards
        for (int i = 0; i < 36; i++)
            // 7 red cards
            if (i < 7)
                this.cardsDeck.add(new Card(i, Color.Red));
            // 7 purple cards
            else if (i < 14)
                this.cardsDeck.add(new Card(i, Color.Purple));
            // 7 blue cards
            else if (i < 21)
                this.cardsDeck.add(new Card(i, Color.Blue));
            // 7 yellow cards
            else if (i < 28)
                this.cardsDeck.add(new Card(i, Color.Yellow));
            // 8 green cards
            else
                this.cardsDeck.add(new Card(i, Color.Green));

        // randomly shuffle cards
        Collections.shuffle(this.cardsDeck);
    }


    /**
     * distributes cards to all players
     */
    private void distributeCards()
    {
        // counter of one player's cards
        int playersHandCount = 0;

        // counter of remaining cards to distribute
        int remainingCards = 36;

        // maximum of 14 cards per player
        while (playersHandCount < 14 && remainingCards >= this.nbPlayers)
        {
            // give each player a card and remove it from deck
            for (Player player : players)
                player.addCardToHand(cardsDeck.remove(0));

            // update remaining cards counter
            remainingCards -= nbPlayers;
            // update counter of players' cards
            ++playersHandCount;
        }

        // if only 1 card remains: show it to players
        // (occurs in 5 players games only
        if (remainingCards == 1)
            displayRemainingCard(cardsDeck.remove(0));
    }


    /**
     * allows a given player to play his turn
     * asks him to play while he didn't make a valid move
     * @param playerID the ID of the player who has to play
     */
    private void play(int playerID)
    {
        // map containing player's move (a card, the floor, and the position)
        Map<String, Object> move;

        do
        {
            // ask the player the move he wants to play
            move = this.players.get(playerID).play(this.board);
        }
        // while player doesn't skip his turn and card can't be added to board
        // (! double check of position)
        while (move != null && !addToBoard(move));

        // if player skips his turn
        if (move == null)
        {
            // increment skips counter
            ++this.skips;
            // player eliminated from the current round
            this.players.get(playerID).setAbleToPlay(false);
        }
    }



    /**
     * displays the card which won't be played this round
     * (only occurs in 5 players games)
     * @param card the card to display
     */
    protected void displayRemainingCard(Card card)
    {
        System.out.println("Color of the card out of the game: "
                            + card.getColor());
    }


    /**
     * add a card to the board if the given position is valid
     * @param card the card to add
     * @param floor the floor to check
     * @param position the position on the given floor
     * @return true if the card was added, false if the position is invalid
     */
    private boolean addToBoard(Card card, int floor, int position)
    {
        // if card and coordinates valid
        if (isCardPlayable(this.board, card, floor, position))
        {
            // add card to board
            this.board[floor][position] = card;
            return true;
        }
        // card not added
        return false;
    }


    /**
     * add a card to the board if the given position is valid
     * @param move a map containing a card and coordinates on the board
     * @return true if the card was added, false if the position is invalid
     */
    private boolean addToBoard(Map<String, Object> move)
    {
        return this.addToBoard(
                (Card)move.get("card"),
                (int)move.get("floor"),
                (int)move.get("position"));
    }



    /**
     * checks if the board is full
     */
    private boolean isBoardFull()
    {
        // for each floor
        for (Card[] floor : this.board)
            // for each square
            for (Card card : floor)
                // if square empty: board not full
                if (card == null)
                    return false;

        return true;
    }


    /**
     * checks whether a card can be played on a given space
     * @param board the board to use
     * @param c the card to test
     * @param floor the floor to check
     * @param position the position to check on the floor
     * @return true if the card can be played, false otherwise
     */
    public static boolean isCardPlayable(Card[][] board, Card c,
                                            int floor, int position)
    {
        // if card is null: not playable
        if (c == null)
            return false;
        // if index is out of bounds (invalid position): return false
        if (floor >= board.length || position >= board[floor].length)
            return false;

        // first floor: no color constraints
        if (floor == 0)
            // card playable if space is empty
            return board[floor][position] == null;

        // index of previous floor
        int prevFloor = floor - 1;
        // index of next position
        int nextPos = position + 1;

        /*
         return true if card can be played, i.e:
         - asked position is free
         - the card rests on two cards on the previous floor
         - the card has the same color as at least one of those two cards
        */

        // position on board has to be free
        if (board[floor][position] == null)

            // check if there are cards on the previous floor
            if (board[prevFloor][position] != null
                    && board[prevFloor][nextPos] != null)

                // check if at least one of those two cards have the same color
                return board[prevFloor][position].getColor() == c.getColor()
                        || board[prevFloor][nextPos].getColor() == c.getColor();

        return false;
    }


    /**
     * overload of the isCardPlayable(Card, int, int) method
     * calls it with arguments found in the map
     * @param move a map containing a card and coordinates on the board
     * @return true if the card can be played, false otherwise
     */
    public static boolean isCardPlayable(Card[][] board,
                                            Map<String, Object> move)
    {
        return isCardPlayable(board,
                (Card)move.get("card"),
                (int)move.get("floor"),
                (int)move.get("position"));
    }


    /**
     * returns the board to display
     */
    protected void displayBoard()
    {
        // number of spaces to print before printing a floor
        int spaces = this.nbFloors * 2;

        // char representing the card's color
        char c;

        // for each floor, starting from the top of the pyramid
        for (int floor = this.nbFloors - 1; floor >= 0; floor--)
        {
            // print spaces
            for (int x = 0; x < spaces; x++)
                System.out.print(' ');

            // for each square in the current floor
            for (int position = 0; position < board[floor].length; position++)
            {
                System.out.print("[");

                // get card's color
                c = this.board[floor][position] != null
                        ? this.board[floor][position].getColorChar()
                        : ' ';

                // print character with card's color
                System.out.print(Color.getAnsiString(c)
                                + c
                                + Color.getAnsiString(' '));

                System.out.print("] ");
            }

            // go on next line
            System.out.println();
            // spaces to print on the next line
            spaces -= 2;
        }
    }


    public int getRoundNumber()
    {
        return this.roundNumber;
    }

    ArrayList<Player> getPlayers()
    {
        return players;
    }

    public boolean isFinished()
    {
        return isFinished;
    }
}