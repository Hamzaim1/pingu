package engine.game;

public class Card
{

    private int idCard;
	private Color color;


	/**
     * create new Card
     * @param color the card's color
     */
    public Card(int id, Color color)
    {
        this.idCard = id;
		this.color = color;
    }


    /**
     * create a Card from another Card
     * @param c the card to use as model
    */
    public Card(Card c)
    {
        this.idCard = c.getIdCard();
        this.color = c.getColor();
    }


    public Card(Color color)
    {
        this.color = color;
    }

	/**
     * show the Card
     */
    void show()
    {
	    System.out.print(" " + this.color + " ");
    }

    Color getColor()
    {
        return this.color;
    }


    /**
     * return a char representing the card's color
     * @return R, B, G, P, or Y; blank space if color not initialized
     */
    public char getColorChar()
    {
        switch (this.color)
        {
            case Red:
                return 'R';
            case Blue:
                return 'B';
            case Green:
                return 'G';
            case Purple:
                return 'P';
            case Yellow:
                return 'Y';
            default:
                return ' ';
        }
    }




    int getIdCard()
    {
        return idCard;
    }

    void setIdCard(int idCard)
    {
        this.idCard = idCard;
    }

    @Override
    public String toString()
    {
        return "Card{" +
                "idCard=" + idCard +
                ", color=" + color +
                '}';
    }
}