package engine.game;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Game
{
    /** stream to read user input */
    static Scanner scan = new Scanner(System.in);

    /** number of players */
    protected int nbPlayers;
    /** list of players */
    private Player[] players;

    /** array of rounds played */
    protected Round[] rounds;


    /**
     * creates a new local game with AI-based players
     * @param p the player creating the game
     */
    public Game(Player p)
    {
        // create tab of players (6 players max)
        this.players = new Player[6];
        // add host to players list
        this.players[0] = p;
        // set players number
        this.nbPlayers = 1;

        // launch game
        this.initLocalGameFromTerminal();
    }


    /**
     * creates a new game
     * @param players   the players playing this game
     * @param nbPlayers the number of players in the game
     */
    public Game(Player[] players, int nbPlayers)
    {
        this.players = players;
        this.nbPlayers = nbPlayers;

        // shuffle players array
        shufflePlayersArray();

        // start game; no need to init, since players are already declared
        start();
    }


    /**
     * asks the user the number of players in the game, creates the players,
     * shuffles them, then starts the game from the terminal (local mode)
     */
    private void initLocalGameFromTerminal()
    {
        // nb of players (from user input)
        String input;
        int nbPlayers = 0;

        do
        {
            System.out.print("Number of players (between 2 and 6): ");
            input = scan.nextLine();

            // if invalid user input
            if (!isInteger(input))
                // prompt again
                continue;

            // convert input to int
            nbPlayers = Integer.parseInt(input);
        }
        while (nbPlayers < 1 || nbPlayers > 6);

        for (int i = 1; i < nbPlayers; i++)
            this.addPlayer(new Player(i));

        // shuffle players array
        this.shufflePlayersArray();

        // start the game
        this.start();
    }


    /**
     * add a player to the game
     * @param p the player to add
     */
    private void addPlayer(Player p)
    {
        // if too many players: end function
        if (this.nbPlayers >= 6)
            return;

        // add new player to list of players
        this.players[this.nbPlayers] = p;
        // update players counter
        ++this.nbPlayers;
    }


    /**
     * starts game and plays all rounds; called when all players are created
     */
    private void start()
    {
        // if not enough players to start the game, end function
        if (nbPlayers <= 1)
            return;

        // initializes rounds array (as many rounds as players)
        initRoundsArray();

        // loop: create and play all rounds
        for (int i = 0; i < nbPlayers; i++)
        {
            // convert to ArrayList before passing it to the round
            rounds[i] = new Round(i,
                                new ArrayList<>(Arrays.asList(this.players)));

            // get new scores after round, and store them into the Game instance
            for (int j = 0; j < nbPlayers; j++)
                this.players[j]
                        .setScore(rounds[i].getPlayers().get(j).getScore());

        }
        // on game ending: display winners
        this.displayWinners();

        // close scanner
        scan.close();
    }


    /**
     * initializes rounds array with the correct number of players
     */
    protected void initRoundsArray()
    {
        this.rounds = new Round[nbPlayers];
    }


    /**
     * shuffles players array
     */
    private void shufflePlayersArray()
    {
        Random rnd = ThreadLocalRandom.current();
        for (int i = this.nbPlayers - 1; i > 0; i--)
        {
            int index = rnd.nextInt(i + 1);
            // Simple swap
            Player p = this.players[index];
            this.players[index] = this.players[i];
            this.players[i] = p;
        }
    }


    /**
     * display the winner(s) of the current game
     */
    protected void displayWinners()
    {
        // array containing players' IDs
        int[] playersID = new int[nbPlayers];
        // array containing players' scores
        int[] scores = new int[nbPlayers];
        // array containing green cards played
        int[] greenCardsPlayed = new int[nbPlayers];

        // fill arrays
        for (int i = 0; i < nbPlayers; i++)
        {
            playersID[i] = players[i].getIdPlayer();
            scores[i] = players[i].getScore();
            greenCardsPlayed[i] = players[i].getNbGreenCardsPlayed();
        }

        // temporary value used to sort
        int temp;
        // sort arrays
        for (int i = 1; i < scores.length; i++)
        {
            for (int j = i; j > 0; j--)
            {
                if (scores[j] < scores[j - 1])
                {
                    temp = scores[j];
                    scores[j] = scores[j - 1];
                    scores[j - 1] = temp;

                    // sort IDs the same way
                    temp = playersID[j];
                    playersID[j] = playersID[j - 1];
                    playersID[j - 1] = temp;

                    // sort green cards the same way
                    temp = greenCardsPlayed[j];
                    greenCardsPlayed[j] = greenCardsPlayed[j - 1];
                    greenCardsPlayed[j - 1] = temp;
                }
            }
        }

        // display results
        System.out.println("results:");
        for (int i = 0; i < nbPlayers; i++)
            System.out.println("    Player " + playersID[i] + ": "
                    + scores[i] + " points; "
                    + greenCardsPlayed[i] + " green cards played");
    }


    /**
     * removes a player from the game
     * @param index the index of the player to kick
     * @return true if player was kicked, false if player not found
     */
    public boolean kickPlayerAtIndex(int index)
    {
        // if index valid and player exists
        if (index < this.nbPlayers && this.players[index] != null)
        {
            // delete player from game
            this.players[index] = null;
            // update players counter
            --this.nbPlayers;
            // player successfully kicked

            // put all players at the beginning of the array
            for (; index < this.nbPlayers; index++)
                this.players[index] = this.players[index + 1];

            return true;
        }
        return false;
    }


    /**
     * checks if a string represents an integer
     * @param str the string to test
     * @return true if the string represents an integer, false if it doesn't
     */
    public static boolean isInteger(String str)
    {
        if (str == null)
        {
            return false;
        }

        if (str.isEmpty())
        {
            return false;
        }

        int length = str.length();
        int i = 0;

        if (str.charAt(0) == '-')
        {
            if (length == 1)
            {
                return false;
            }
            i = 1;
        }

        for (; i < length; i++)
        {
            char c = str.charAt(i);
            if (c < '0' || c > '9')
            {
                return false;
            }
        }
        return true;
    }

}