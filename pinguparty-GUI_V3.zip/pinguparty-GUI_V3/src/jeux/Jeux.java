/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeux;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author HELLO
 */
public class Jeux extends JFrame {
      private int indice = 0;
      private CardLayout cl = new CardLayout();
      private JLabel TitreMenu;

   Jeux(){
    this.setTitle("PinguParty");
    this.setSize(700, 600);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLocationRelativeTo(null);
    JButton ButtonCreationpartie = new JButton("Creation de partie locale");
    //DÃ©finition de l'action du bouton2
    ButtonCreationpartie.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Jeux.this.indice = 1;
        new local().setVisible(true);
        }
    });
    JButton ButtonCreationNetwork = new JButton("Creation de partie r�seau");
    //DÃ©finition de l'action du bouton2
    ButtonCreationNetwork.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Jeux.this.indice = 2;
        new reseau().setVisible(true);
        }
    });
    JButton ButtonRejoindreNet = new JButton("Rejoindre une partie r�seau");
    //DÃ©finition de l'action du bouton2
    ButtonRejoindreNet.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Jeux.this.indice = 4;
        }
    });
    JButton ButtonProfile = new JButton("Gestion des profile locaux");
    //DÃ©finition de l'action du bouton2
    ButtonProfile.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Jeux.this.indice = 5;
        }
    });
    JButton ButtonStats = new JButton("Statistiques");
    //DÃ©finition de l'action du bouton2
    ButtonStats.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	new Stats().setVisible(true);
        }
    });
    JButton ButtonOption = new JButton("Options et parram�tre");
    //DÃ©finition de l'action du bouton2
    ButtonOption.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Jeux.this.indice = 0;
       }
    });
    
    JButton bouton7 = new JButton("Quitter");
    //DÃ©finition de l'action du bouton2
    bouton7.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	  System.exit(0);
      }
    });
    JPanel boutons = new JPanel();
    boutons.setLayout(new GridLayout(7, 1,10,10));
    boutons.setPreferredSize(new Dimension(300,200));
    boutons.setBackground(Color.LIGHT_GRAY);
    boutons.add(ButtonCreationpartie);
    boutons.add(ButtonCreationNetwork);
    boutons.add(ButtonRejoindreNet);
    boutons.add(ButtonProfile);
    boutons.add(ButtonStats);
    boutons.add(ButtonOption);
    boutons.add(bouton7);
 
  //titre
    JLabel titre1 = new JLabel();
    Font police = new Font("Arial", Font.BOLD, 30);
    TitreMenu = new JLabel("MENU PRICIPALE");
    TitreMenu.setBackground(Color.BLACK);
    TitreMenu.setFont(police);
    TitreMenu.setForeground(Color.BLACK);
    
    
    
    
    
    
    
    // on ajoute le titre et boutons au card1
    JPanel PannelTop = new JPanel();
    PannelTop.setPreferredSize(new Dimension(600,100));
    PannelTop.add(TitreMenu);
    PannelTop.setBorder(BorderFactory.createEmptyBorder(25,10,10,10));
    PannelTop.setBackground(Color.LIGHT_GRAY);
    JPanel PannelGauche = new JPanel();
    PannelGauche.setPreferredSize(new Dimension(160, 600));
    PannelGauche.setBackground(Color.LIGHT_GRAY);
    JPanel Panneldroite = new JPanel();
    Panneldroite.setPreferredSize(new Dimension(160, 600));
    Panneldroite.setBackground(Color.LIGHT_GRAY);
    JPanel PannelBas = new JPanel();
    PannelBas.setPreferredSize(new Dimension(800, 100));
    PannelBas.setBackground(Color.LIGHT_GRAY);

    
    
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(PannelGauche, BorderLayout.WEST);
    getContentPane().add(Panneldroite, BorderLayout.EAST);
    getContentPane().add(PannelBas, BorderLayout.SOUTH);
    getContentPane().add(PannelTop,BorderLayout.NORTH);
    getContentPane().add(boutons,BorderLayout.CENTER);
   }
    public static void main(String[] args) {
        new Jeux ().setVisible(true);

        
    }
    
}
