/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeux;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author HELLO
 */
public class local extends javax.swing.JFrame {

  public int nbPlayers = 2;
  public int [] nbCartesForPlayers = new int[this.nbPlayers];
  public String[] Players_tab = {"Humain 1","Humain 2","IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
  public String[] Players_tabIA = {"IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
  public ButtonGroup bg_P2 = new ButtonGroup();
  public JPanel centerPanel_P2 = new JPanel();
  public JComboBox[] tab_combo1 = new JComboBox[6];
  public JPanel choixPanel_P2 = new JPanel();
  
    Color colorCarte;
  Color[]mesCartesColor= {Color.BLUE,Color.GREEN,Color.RED,Color.MAGENTA,Color.YELLOW};
  JPanel [] mesCartes =new JPanel [6];
  //public JPanel [][] triangle =new JPanel [8][];
  //public boolean updateP3 = false;
  public JPanel leftPanelP4 = new JPanel();
  public JPanel rightPanelP4 = new JPanel();
  JPanel bottomPanelP4 = new JPanel();
  public JPanel centerPanelP4 = new JPanel();
  public JPanel topPanelP4 = new JPanel();
  public boolean monTour = true;
  boolean updateP4 = false;
  
  Component tmpCont = null;
  Component tmp2Cont = null;
  Component tmp3Cont = null;
  JPanel triangleCont =new JPanel();
  public JPanel [] etageTriangle =new JPanel [8];
  JPanel [][] triangle =new JPanel [8][];
  Thread t2;
  
  JPanel[][] cartesForOthers = new JPanel[6][15];
  JPanel leftTopP4 = new JPanel();
	JPanel leftBottomP4 = new JPanel();
	JPanel rightTopP4 = new JPanel();
	JPanel rightBottomP4 = new JPanel();
  Thread t;
    JLabel[] labelIpP3= new JLabel[5];

    /**
     * Creates new form local
     */
    public local() {
        initComponents();
    this.setTitle("PinguParty");
    this.setSize(700, 600);
        Font police2 = new Font("Arial", Font.BOLD, 20);
    JRadioButton jr1_P2 = new JRadioButton("2");
    jr1_P2.setForeground(Color.WHITE);
    jr1_P2.setBackground(Color.DARK_GRAY);
    jr1_P2.setActionCommand("2");
    jr1_P2.setFont(police2);
    JRadioButton jr2_P2 = new JRadioButton("3");
    jr2_P2.setBackground(Color.DARK_GRAY);
    jr2_P2.setForeground(Color.WHITE);
    jr2_P2.setActionCommand("3");
    jr2_P2.setFont(police2);
    JRadioButton jr3_P2 = new JRadioButton("4");
    jr3_P2.setBackground(Color.DARK_GRAY);
    jr3_P2.setForeground(Color.WHITE);
    jr3_P2.setActionCommand("4");
    jr3_P2.setFont(police2);
    JRadioButton jr4_P2 = new JRadioButton("5");
    jr4_P2.setBackground(Color.DARK_GRAY);
    jr4_P2.setForeground(Color.WHITE);
    jr4_P2.setActionCommand("5");
    jr4_P2.setFont(police2);
    JRadioButton jr5_P2 = new JRadioButton("6");
    jr5_P2.setBackground(Color.DARK_GRAY);
    jr5_P2.setForeground(Color.WHITE);
    jr5_P2.setActionCommand("6");
    jr5_P2.setFont(police2);
    
    jr1_P2.setSelected(true);
    jr1_P2.addActionListener(new radio_P2Listener());
    jr2_P2.addActionListener(new radio_P2Listener());
    jr3_P2.addActionListener(new radio_P2Listener());
    jr4_P2.addActionListener(new radio_P2Listener());
    jr5_P2.addActionListener(new radio_P2Listener());
    
 
    
    this.bg_P2.add(jr1_P2);
    this.bg_P2.add(jr2_P2);
    this.bg_P2.add(jr3_P2);
    this.bg_P2.add(jr4_P2);
    this.bg_P2.add(jr5_P2);
    JLabel label1_P2 = new JLabel("Nombre de joueurs :    ");
    label1_P2.setForeground(Color.white);
    label1_P2.setFont(police2);
    
    JPanel top_P2 = new JPanel();
    top_P2.setBackground(Color.DARK_GRAY);
	  top_P2.add(label1_P2);
	  top_P2.add(jr1_P2);
	  top_P2.add(jr2_P2);
	  top_P2.add(jr3_P2);
	  top_P2.add(jr4_P2);
	  top_P2.add(jr5_P2);

	  
	  JPanel leftPanel_P2 = new JPanel();
	    leftPanel_P2.setPreferredSize(new Dimension(160, 600));
	    leftPanel_P2.setBackground(Color.DARK_GRAY);
	    JPanel rightPanel_P2 = new JPanel();
	    rightPanel_P2.setPreferredSize(new Dimension(160, 600));
	    rightPanel_P2.setBackground(Color.DARK_GRAY);
	    JPanel bottomPanel_P2 = new JPanel();
	    bottomPanel_P2.setPreferredSize(new Dimension(800, 100));
	    bottomPanel_P2.setBackground(Color.DARK_GRAY);
	    JPanel centerPanel_P2 = new JPanel();
	    centerPanel_P2.setBackground(Color.DARK_GRAY);
	    JButton bouton_P2 = new JButton("COMMECER");
	    JButton bouton2_P2 = new JButton("ANNULER");
	    
	    bouton_P2.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
            new start().setVisible(true);
        }
    });
	    
	    bouton2_P2.addActionListener(new ActionListener(){
	        @Override
			public void actionPerformed(ActionEvent event){
	    
	        }
	      });
	    
	    
	    bottomPanel_P2.add(bouton_P2);
	    bottomPanel_P2.add(bouton2_P2);
	    
	    this.setLayout(new BorderLayout());
            this.add(top_P2, BorderLayout.NORTH);
	    this.add(leftPanel_P2, BorderLayout.WEST);
	    this.add(rightPanel_P2, BorderLayout.EAST);
	    this.add(bottomPanel_P2, BorderLayout.SOUTH);
	    this.add(centerPanel_P2,BorderLayout.CENTER);
	    
	    
        this.choixPanel_P2.setLayout(new GridLayout(6, 1,10,10));
        this.choixPanel_P2.setPreferredSize(new Dimension(200,70));
        this.choixPanel_P2.setBackground(Color.DARK_GRAY);
        centerPanel_P2.add(this.choixPanel_P2);
        this.choixPanel_P2.setBorder(BorderFactory.createEmptyBorder(60,10,10,10));
        
	    for(int i = 0; i < this.tab_combo1.length; i++){
	    	if(i==0)
	    	 this.tab_combo1[i] = new JComboBox(this.Players_tab);
	    	else this.tab_combo1[i] = new JComboBox(this.Players_tabIA);
	    	if(this.Players_tab.length >= i)this.tab_combo1[i].setSelectedIndex(i);
	        this.choixPanel_P2.add(this.tab_combo1[i]);
	  	  }
	    for(int i = this.tab_combo1.length-1; i >=this.nbPlayers;i--){
	    	
	    		this.tab_combo1[i].setEnabled(false);
	    };
	    this.add(this.choixPanel_P2, BorderLayout.CENTER);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    class radio_P2Listener implements ActionListener{
      @Override
	public void actionPerformed(ActionEvent e) {
    	  boolean diminue;
    	  int n = Integer.parseInt(e.getActionCommand());
    	  if(local.this.nbPlayers>n) diminue =true;
    	  else diminue = false;
    	  local.this.nbPlayers =n;
    	  //local.this.nbCartesForPlayers = new int[local.this.nbPlayers];
    	  setnbCartesForPlayers();
    	if(diminue ==true)  
    	{  for(int i = local.this.tab_combo1.length-1; i >=local.this.nbPlayers;i--){
	
	  	    		local.this.tab_combo1[i].setEnabled(false);
	  	    };
    	}
	  	else for(int i = 0; i <local.this.nbPlayers;i++){
	  		
	    		local.this.tab_combo1[i].setEnabled(true);
	    };
  	  
	    local.this.t2 = new Thread(new cartesForPlayersP4());

	      local.this.t2.start();
  	  
      }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(local.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(local.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(local.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(local.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new local().setVisible(true);
            }
        });
    }
void setnbCartesForPlayers()
  {		int tmp =0;
	  switch (this.nbPlayers) {
      case 2:  tmp= 14;
               break;
      case 3:  tmp= 12;
               break;
      case 4:  tmp= 9;
               break;
      case 5:  tmp= 7;
      			break;
      case 6:  tmp= 6;
      			break;
      default: break;
	  }
	  for(int i =0;i<this.nbCartesForPlayers.length;i++)
		  this.nbCartesForPlayers[i]=tmp;
               
  }
class cartesForPlayersP4 implements Runnable{

	    @Override
		public void run() {
	    	local.this.rightBottomP4.removeAll();
	    	local.this.topPanelP4.removeAll();
	    	
	    	local.this.leftTopP4.removeAll();
	    	local.this.leftBottomP4.removeAll();
	    	local.this.rightTopP4.removeAll();
	    	for(int i =1;i<local.this.nbPlayers;i++)
		    {	for(int x =0;x<local.this.nbCartesForPlayers[i]-1;x++)
		    	{	local.this.cartesForOthers[i][x] = new JPanel();
		    	local.this.cartesForOthers[i][x].setPreferredSize(new Dimension(20,35 ));
		    	local.this.cartesForOthers[i][x].setBackground(Color.white);
		    		if(i==1)
		    		{
			    	
			    	
		    			
			    	local.this.topPanelP4.add(local.this.cartesForOthers[i][x]);
		    		}
		    		else if(i==2)
		    		{
		    			
			    	local.this.leftTopP4.add(local.this.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==3)
		    		{
		    			
		    			local.this.leftBottomP4.add(local.this.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==4)
		    		{
		    			
		    			local.this.rightTopP4.add(local.this.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==5)
		    		{
		    			
		    			local.this.rightBottomP4.add(local.this.cartesForOthers[i][x]);
			    	
		    		}
		    	}
		    	
		    }
	    	local.this.leftPanelP4.removeAll();
		    local.this.leftPanelP4.setLayout(new GridLayout(2,1));
		    local.this.leftPanelP4.add(local.this.leftTopP4);
	    	local.this.leftPanelP4.add(local.this.leftBottomP4);
	    	local.this.rightPanelP4.removeAll();
	    	local.this.rightPanelP4.setLayout(new GridLayout(2,1));
		    local.this.rightPanelP4.add(local.this.rightTopP4);
	    	local.this.rightPanelP4.add(local.this.rightBottomP4);

	    }
	}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
