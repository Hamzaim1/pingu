/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeux;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author HELLO
 */
public class reseau extends javax.swing.JFrame {
    local lc = new local();
  private JLabel[] labelIpP3 = new JLabel[5];

  private int nbPlayers = 2;
    private int nbLocalPlayers =1;
  //private boolean updateP3 = false;
  private JPanel leftPanelP3 = new JPanel();
  private JPanel rightPanelP3 = new JPanel();
  private JPanel bottomPanelP3 = new JPanel();
  private JPanel centerPanelP3 = new JPanel();
  private JPanel topPanelP3 = new JPanel();

  private JButton bouton_P3 = new JButton("COMMECER");
  private JButton bouton2_P3 = new JButton("ANNULER");
  private Font police3 = new Font("Arial", Font.BOLD, 15);
  private ButtonGroup bgP3 = new ButtonGroup();
  private ButtonGroup bg2P3 = new ButtonGroup();
  private JRadioButton[] tab1RadioButtonP3 = new JRadioButton[5];
  private JRadioButton[] tab2RadioButtonP3 = new JRadioButton[5];
  private JComboBox[] tabComboP3 = new JComboBox[5];
  private JPanel radioPanelP3 = new JPanel();
  private JPanel radio2PanelP3 = new JPanel();
  private JLabel labelRadio1P3 = new JLabel("Nombre maximal de joueurs : ");
  private JLabel labelRadio2P3 = new JLabel("Nombre de joueurs locaux : ");
  private JPanel[] panelSlotsP3 = new JPanel[6];
  private JLabel[] labelSlotsP3 = new JLabel[6];
  private JButton[] kickButton = new JButton[5];
  private String testIp =" <adresse ip> ";
  private Thread t;
private String[] Players_tab = {"Humain 1","Humain 2","IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
  private String[] Players_tabIA = {"IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
    public reseau() {
        initComponents();
    this.setTitle("PinguParty");
    this.setSize(700, 600);
        this.labelRadio1P3.setForeground(Color.white);
	    this.labelRadio1P3.setFont(this.police3);
	    this.labelRadio2P3.setForeground(Color.white);
	    this.labelRadio2P3.setFont(this.police3);
	    
	    this.radioPanelP3.add(this.labelRadio1P3);
	    this.radioPanelP3.setBackground(Color.DARK_GRAY);
	    this.radio2PanelP3.add(this.labelRadio2P3);
	    this.radio2PanelP3.setBackground(Color.DARK_GRAY);
	    
	    for(int i=0;i<this.tab1RadioButtonP3.length;i++)
	    {
	    	this.tab1RadioButtonP3[i] = new JRadioButton(Integer.toString(i+2));
	    	this.tab1RadioButtonP3[i].setForeground(Color.WHITE);
	    	this.tab1RadioButtonP3[i].setBackground(Color.DARK_GRAY);
	    	this.tab1RadioButtonP3[i].setActionCommand(Integer.toString(i+2));
	    	this.tab1RadioButtonP3[i].setFont(this.police3);
	    	this.tab1RadioButtonP3[i].addActionListener(new tab1RadioListenerP3());
	    	//tab1RadioButtonP3[i].addActionListener(new radioListenerP3());
	    	this.bgP3.add(this.tab1RadioButtonP3[i]);
	    	this.radioPanelP3.add(this.tab1RadioButtonP3[i]);
	    }
	    for(int i=0;i<this.tab2RadioButtonP3.length;i++)
	    {
	    	this.tab2RadioButtonP3[i] = new JRadioButton(Integer.toString(i+1));
	    	this.tab2RadioButtonP3[i].setForeground(Color.WHITE);
	    	this.tab2RadioButtonP3[i].setBackground(Color.DARK_GRAY);
	    	this.tab2RadioButtonP3[i].setActionCommand(Integer.toString(i+1));
	    	this.tab2RadioButtonP3[i].setFont(this.police3);
	    	this.tab2RadioButtonP3[i].addActionListener(new tab2RadioListenerP3());
	    	//tab2RadioButtonP3[i].addActionListener(new radioListenerP3());
	    	this.bg2P3.add(this.tab2RadioButtonP3[i]);
	    	this.radio2PanelP3.add(this.tab2RadioButtonP3[i]);
	    	if(i>=this.nbLocalPlayers) this.tab2RadioButtonP3[i].setEnabled(false);
	    }
	    this.tab1RadioButtonP3[0].setSelected(true);
	    this.tab2RadioButtonP3[0].setSelected(true);
	    
	    
	    
	    
	    this.topPanelP3.setLayout(new GridLayout(2,1));
	    this.topPanelP3.setBackground(Color.DARK_GRAY);
		this.topPanelP3.add(this.radioPanelP3);
		this.topPanelP3.add(this.radio2PanelP3);
		

		  

		    this.leftPanelP3.setPreferredSize(new Dimension(160, 600));
		    this.leftPanelP3.setBackground(Color.DARK_GRAY);
		    this.rightPanelP3.setPreferredSize(new Dimension(160, 600));
		    this.rightPanelP3.setBackground(Color.DARK_GRAY);
		    this.bottomPanelP3.setPreferredSize(new Dimension(800, 100));
		    this.bottomPanelP3.setBackground(Color.DARK_GRAY);
		    this.centerPanelP3.setBackground(Color.DARK_GRAY);
		    
		    this.bouton_P3.addActionListener(new ActionListener(){
	      @Override
		public void actionPerformed(ActionEvent event){
                    new start().setVisible(true);
	  	      }
	    });
		    
		    this.bouton2_P3.addActionListener(new ActionListener(){
		        @Override
				public void actionPerformed(ActionEvent event){
		    new Jeux().setVisible(true);
		        }
		      });
		    
		    
		    this.bottomPanelP3.add(this.bouton_P3);
		    this.bottomPanelP3.add(this.bouton2_P3);
		    
		    this.setLayout(new BorderLayout());
			this.add(this.topPanelP3, BorderLayout.NORTH);
		    this.add(this.leftPanelP3, BorderLayout.WEST);
		    this.add(this.rightPanelP3, BorderLayout.EAST);
		    this.add(this.bottomPanelP3, BorderLayout.SOUTH);
		    this.add(this.centerPanelP3,BorderLayout.CENTER);
		    
		    this.centerPanelP3.setLayout(new GridLayout(6, 1, 5,2));
		    int j =0;
		    for(int i =0;i< this.nbPlayers;i++)
		    {	
		    	this.panelSlotsP3[i] = new JPanel();
		    	this.panelSlotsP3[i].setLayout(new GridLayout(1, 3));
		    	this.panelSlotsP3[i].setBackground(Color.DARK_GRAY);
		    	
		    	this.labelSlotsP3[i] = new JLabel("Slot "+Integer.toString(i+1)+": ");
		    	this.labelSlotsP3[i].setForeground(Color.white);
			    this.labelSlotsP3[i].setFont(this.police3);
			    
			    this.panelSlotsP3[i].add(this.labelSlotsP3[i]);
			    if(i<this.nbLocalPlayers)
			    {
				    if(i==0)
				    	this.tabComboP3[i] = new JComboBox(this.Players_tab);
				    else this.tabComboP3[i] = new JComboBox(this.Players_tabIA);
			    	if(this.Players_tab.length >= i)this.tabComboP3[i].setSelectedIndex(i);
			    	this.panelSlotsP3[i].add(this.tabComboP3[i]);
			    }
			    else
			    {
			    	this.labelIpP3[j] = new JLabel(this.testIp);
			    	this.labelIpP3[j].setForeground(Color.white);
				    this.labelIpP3[j].setFont(this.police3);
				    this.panelSlotsP3[i].add(this.labelIpP3[j]);
				    
				    this.kickButton[j] = new JButton("Kick");
				    System.out.println(j);
				    this.kickButton[j].setActionCommand(Integer.toString(j));
				    this.kickButton[j].addActionListener(new kickListenerP3());
				    this.panelSlotsP3[i].add(this.kickButton[j]);
				    
				    j++;
			    }
			    this.centerPanelP3.add(this.panelSlotsP3[i]);    
		    }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reseau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reseau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reseau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reseau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reseau().setVisible(true);
            }
        });
    }
  class tab1RadioListenerP3 implements ActionListener{
      @Override
	public void actionPerformed(ActionEvent e) {
 
    	  reseau.this.nbPlayers =Integer.parseInt(e.getActionCommand());
    	 lc.nbCartesForPlayers = new int[reseau.this.nbPlayers];
    	  lc.setnbCartesForPlayers();
    	for(int i = 0; i <reseau.this.tab2RadioButtonP3.length;i++){
	  		
	    		if(i<reseau.this.nbPlayers-1)reseau.this.tab2RadioButtonP3[i].setEnabled(true);
	    		else reseau.this.tab2RadioButtonP3[i].setEnabled(false);
	    		
	    		
	    };
	    reseau.this.tab2RadioButtonP3[0].setSelected(true);
	    reseau.this.nbLocalPlayers=1;
	    reseau.this.t = new Thread(new UpdateWindow());

	      reseau.this.t.start();
	      lc.t2 = new Thread(new cartesForPlayersP4());

  	      lc.t2.start();
	    //updateP3 = true;
      }
    }
    class tab2RadioListenerP3 implements ActionListener{
      @Override
	public void actionPerformed(ActionEvent e) {
    	  reseau.this.nbLocalPlayers =Integer.parseInt(e.getActionCommand());
    	  //updateP3 = true;
    	  reseau.this.t = new Thread(new UpdateWindow());

          reseau.this.t.start();
          lc.t2 = new Thread(new cartesForPlayersP4());

  	      lc.t2.start();
      }
}
   class UpdateWindow implements Runnable{

	    @Override
		public void run() {

	    	updateP3();    

	    }  

	  }
   
     private void updateP3(){
	 // nbLocalPlayers=1;
	  int j =0;
	  this.centerPanelP3.removeAll();
	  
	    for(int i =0;i< this.nbPlayers;i++)
	    {	
	    	//System.out.println("updateP3 : indice : "+i);
	    	//panelSlotsP3[i].removeAll();
	    	//panelSlotsP3[i] = null;
	    	this.panelSlotsP3[i] = new JPanel();//
	    	this.panelSlotsP3[i].setLayout(new GridLayout(1, 3));
	    	this.panelSlotsP3[i].setBackground(Color.DARK_GRAY);
	    	//System.out.println("updateP3 : indice : "+i);
	    	//labelSlotsP3[i].removeAll();
	    	this.labelSlotsP3[i] = new JLabel("Slot "+Integer.toString(i+1)+": ");
	    	//labelSlotsP3[i].setText("Slot "+Integer.toString(i+1)+": ");
	    	this.labelSlotsP3[i].setForeground(Color.white);
		    this.labelSlotsP3[i].setFont(this.police3);
		    
		    this.panelSlotsP3[i].add(this.labelSlotsP3[i]);
		    if(i<this.nbLocalPlayers)
		    {
		    	//tabComboP3[i].removeAll();
			    if(i==0)this.tabComboP3[i] = new JComboBox(this.Players_tab);
			    else this.tabComboP3[i] = new JComboBox(this.Players_tabIA);
		    	if(this.Players_tab.length > i)this.tabComboP3[i].setSelectedIndex(i);//
		    	this.panelSlotsP3[i].add(this.tabComboP3[i]);
		    }
		    else
		    {
		    	//labelIpP3[j].removeAll();
		    	this.labelIpP3[j] = new JLabel(this.testIp);
		    	this.labelIpP3[j].setForeground(Color.white);
			    this.labelIpP3[j].setFont(this.police3);
			    this.panelSlotsP3[i].add(this.labelIpP3[j]);
			    //kickButton[j].removeAll();
			    this.kickButton[j] = new JButton("Kick");
			    //System.out.println(j);
			    this.kickButton[j].setActionCommand(Integer.toString(j));
			    this.kickButton[j].addActionListener(new kickListenerP3());
			    this.panelSlotsP3[i].add(this.kickButton[j]);
			    
			    j++;
		    }
		    
		    this.centerPanelP3.add(this.panelSlotsP3[i]);
		   // updateP3=false;
		    
		    
		    
	    //}
	 }
	    lc.t2 = new Thread(new cartesForPlayersP4());

	      lc.t2.start();
	 //SwingUtilities.updateComponentTreeUI(reseau.this);
	    reseau.this.invalidate();
	    reseau.this.validate();
	    reseau.this.repaint();
	  
  }
       class kickListenerP3 implements ActionListener{

      @Override
	public void actionPerformed(ActionEvent event){
      	reseau.this.labelIpP3[Integer.parseInt(event.getActionCommand())].setText(" Libre ");
	        }
    }
       
       class cartesForPlayersP4 implements Runnable{

	    @Override
		public void run() {
	    	lc.rightBottomP4.removeAll();
	    	lc.topPanelP4.removeAll();
	    	
	    	lc.leftTopP4.removeAll();
	    	lc.leftBottomP4.removeAll();
	    	lc.rightTopP4.removeAll();
	    	for(int i =1;i<lc.nbPlayers;i++)
		    {	for(int x =0;x<lc.nbCartesForPlayers[i]-1;x++)
		    	{	lc.cartesForOthers[i][x] = new JPanel();
		    	lc.cartesForOthers[i][x].setPreferredSize(new Dimension(20,35 ));
		    	lc.cartesForOthers[i][x].setBackground(Color.white);
		    		if(i==1)
		    		{
			    	
			    	
		    			
			    	lc.topPanelP4.add(lc.cartesForOthers[i][x]);
		    		}
		    		else if(i==2)
		    		{
		    			
			    	lc.leftTopP4.add(lc.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==3)
		    		{
		    			
		    			lc.leftBottomP4.add(lc.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==4)
		    		{
		    			
		    			lc.rightTopP4.add(lc.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==5)
		    		{
		    			
		    			lc.rightBottomP4.add(lc.cartesForOthers[i][x]);
			    	
		    		}
		    	}
		    	
		    }
	    	lc.leftPanelP4.removeAll();
		    lc.leftPanelP4.setLayout(new GridLayout(2,1));
		    lc.leftPanelP4.add(lc.leftTopP4);
	    	lc.leftPanelP4.add(lc.leftBottomP4);
	    	lc.rightPanelP4.removeAll();
	    	lc.rightPanelP4.setLayout(new GridLayout(2,1));
		    lc.rightPanelP4.add(lc.rightTopP4);
	    	lc.rightPanelP4.add(lc.rightBottomP4);

	    }
	}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
