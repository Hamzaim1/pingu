package network;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Service extends Thread
{
    /** server which created the service */
    private Server server;

    /** ServerSocket used to listen to clients */
    private ServerSocket serverSocket;


    /**
     * default constructor
     * initializes a new service, waiting for clients to connect
     */
    Service(Server server)
    {
        this.server = server;
    }

    // https://github.com/frazerbw/JavaLobby/tree/master/src/com/frazerbw/lobby


    /**
     * code running when thread starts
     */
    public void run()
    {
        // init server's socket with port set in ServerSettings class
        this.initServerSocket();

        // while game not started: wait for clients to connect
        while (!serverSocket.isClosed())
            acceptNewClient();
    }


    /**
     * initializes server's socket with port set in ServerSettings class
     */
    private void initServerSocket()
    {
        try
        {
            // init serverSocket
            this.serverSocket = new ServerSocket(ServerSettings.SERVER_PORT);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }


    /**
     * waits for a client to connect
     * if there is room in lobby: creates a thread communicating with the client
     * otherwise refuses connection
     */
    private void acceptNewClient()
    {
        try
        {
            System.out.println("waiting for clients...");
            // wait for a client to connect
            Socket socket = this.serverSocket.accept();

            // if too many clients
            if (!server.canAddNewClient())
            {
                System.out.println("too many clients");
                System.out.println("nb clients connected: "
                        + server.getNbPlayers());
                // close socket
                socket.close();
            }
            else
            {
                System.out.println("accepting new client");

                // else: create a new client
                addNewOnlinePlayer(socket);
            }

        }
        catch (IOException e)
        {
            // no need to print stack trace
            Server.printDebug("socket closed");
        }
    }


    /**
     * creates a ClientHandler to communicate with client
     * @param socket the socket used to communicate with the client
     */
    private void addNewOnlinePlayer(Socket socket)
    {
        // new player's ID
        int playerID = server.getFistAvailableSlotIndex();

        // instantiate new human player to add to the server
        OnlinePlayer p = new OnlinePlayer(playerID, socket, true);

        // add OnlinePlayer to server
        server.addPlayer(p);
    }


    void closeServerSocket()
    {
        try
        {
            System.out.println("closing server socket");
            serverSocket.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}