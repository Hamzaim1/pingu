package network;

import engine.game.Player;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientHandler
{
    /** server which created the service */
    private Server server;
    /** ID of the current service */
    private int clientID;

    /** socket used to communicate with the client */
    private Socket socket;

    /** stream to receive messages from client */
    private ObjectInputStream in;
    /** stream to send messages to client */
    private ObjectOutputStream out;

    /** client's player instance */
    private Player player;


    /**
     * default constructor
     * @param socket socket to use to communicate with the client
     */
    ClientHandler(Socket socket)
    {
        // socket used to communicate with client
        this.socket = socket;

        // init streams used to communicate with clients
        initStreams();
    }


    /**
     * init streams used to communicate with clients
     */
    private void initStreams()
    {
        try
        {
            // output stream
            this.out = new ObjectOutputStream(socket.getOutputStream());
            // input stream
            this.in = new ObjectInputStream(socket.getInputStream());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


    /**
     * writes the given message to the output stream, then flushes it
     * @param message the message to send
     */
    void sendMessage(String message)
    {
        writeMessage(message);
        flushMessage();
    }


    /**
     * writes the given message in the output stream without flushing it
     * @param message the message to write
     */
    private void writeMessage(String message)
    {
        try
        {
            out.writeObject(message);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


    /**
     * flushes all written messages to client
     */
    private void flushMessage()
    {
        try
        {
            out.flush();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


    String readString()
    {
        String userInput = null;
        try
        {
            userInput = (String)in.readObject();
        }
        catch (IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }

        return userInput;
    }

}