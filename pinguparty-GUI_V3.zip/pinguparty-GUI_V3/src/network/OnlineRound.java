package network;

import engine.game.*;
import java.util.ArrayList;

public class OnlineRound extends Round
{

    /**
     * initializes attributes, then starts offline game from prompt
     * @param roundNumber number of the round into the game (first, second...)
     * @param players     list of players
     */
    OnlineRound(int roundNumber, ArrayList<Player> players)
    {
        // init round
        super(roundNumber, players);
    }


    /**
     * sends the board to display to all clients
     */
    @Override
    protected void displayBoard()
    {
        // board to display
        StringBuilder ret = new StringBuilder();

        // number of spaces to print before printing a floor
        int spaces = this.nbFloors * 2;

        // char representing the card's color
        char c;

        // for each floor, starting from the top of the pyramid
        for (int floor = this.nbFloors - 1; floor >= 0; floor--)
        {
            // print spaces
            for (int x = 0; x < spaces; x++)
                ret.append(' '); //System.out.print(' ');

            // for each square in the current floor
            for (int position = 0; position < board[floor].length; position++)
            {
                ret.append('['); // System.out.print("[");

                // get card's color
                c = this.board[floor][position] != null
                        ? this.board[floor][position].getColorChar()
                        : ' ';

                // print character with card's color
                // System.out.print(Color.getAnsiString(c)
                //                 + c
                //                 + Color.getAnsiString(' '));
                ret.append(Color.getAnsiString(c))
                        .append(c)
                        .append(Color.getAnsiString(' '));

                ret.append("] "); // System.out.print("] ");
            }

            // go on next line
            ret.append("\n"); // System.out.println();
            // spaces to print on the next line
            spaces -= 2;
        }

        // send string to clients
        sendToAllPlayers(ret.toString());
    }


    /**
     * TODO: send color to clients
     * displays the card which won't be played this round
     * (only occurs in 5 players games)
     * @param card the card to display
     */
    @Override
    protected void displayRemainingCard(Card card)
    {
        sendToAllPlayers("Color of the card out of the game: "
                + card.getColor());
    }


    /**
     * sends the given string to all connected clients
     * @param message the message to send
     */
    @Override
    protected void sendToAllPlayers(String message)
    {
        for (Player player : players)
            player.sendMessage(message);
    }
}