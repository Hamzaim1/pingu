package network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client
{
    /** socket used to communicate with the server */
    private Socket socket;

    /** stream to receive messages from server */
    private ObjectInputStream in;
    /** stream to send messages to server */
    private ObjectOutputStream out;


    /**
     * default constructor; connects to local host
     * @throws IOException if the socket can't connect
     */
    public Client() throws IOException
    {
        initSocket();
    }


    /**
     * initializes socket and streams used to communicate with the server
     * @throws IOException when the connection is unavailable
     */
    private void initSocket() throws IOException
    {
        // socket tries to connect to local host
        socket = new Socket(InetAddress.getLocalHost(), 4242);
        // stream to send messages
        out = new ObjectOutputStream(socket.getOutputStream());
        // stream to receive messages
        in = new ObjectInputStream(socket.getInputStream());
    }


    public void sendMessage(String message)
    {
        writeMessage(message);
        flushMessage();
    }


    /**
     * writes the given message in the output stream without flushing it
     * @param message the message to write
     */
    private void writeMessage(String message)
    {
        try
        {
            out.writeObject(message);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


    /**
     * flushes all written messages to client
     */
    private void flushMessage()
    {
        try
        {
            out.flush();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


    public String readString()
    {
        String userInput = null;
        try
        {
            userInput = (String)in.readObject();
        }
        catch (IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }

        return userInput;
    }


    /**
     * waits for server output (functional approach)
     * used for console-based game
     */
    @Deprecated
    private void communicateWithServer() throws ClassNotFoundException, IOException
    {
        // stream to read user inputs from console
        Scanner scan = new Scanner(System.in);

        // string to store user inputs
        String userInput;
        // string to store server outputs
        String serverOutput;

        while (true)
        {
            // read message from server
            serverOutput = (String)in.readObject();

            // if server asks for user input
            if (serverOutput.equals("\\"))
            {
                // prompt answer
                System.out.print("Answer: ");
                // get user input
                userInput = scan.nextLine();

                // if user asks to quit
                if (userInput.equals("q") || userInput.equals("quit"))
                    break;

                // write answer in output stream
                out.writeObject(userInput);
                // send it
                out.flush();
            }
            // else: print server message
            else
                System.out.println(serverOutput);

        }
    }



}
