package network;

import engine.game.*;

import java.net.Socket;
import java.util.Map;

class OnlinePlayer extends Player
{
    /** used to communicate with client */
    private ClientHandler client;


    /**
     * create new IA-based OnlinePlayer
     * @param idPlayer id of player
     */
    OnlinePlayer(int idPlayer, Socket socket)
    {
        super(idPlayer);

        // used to communicate with client
        this.client = new ClientHandler(socket);
    }

    /**
     * create new OnlinePlayer
     * @param idPlayer id of player
     * @param isHuman  whether the player is a human or an AI
     */
    OnlinePlayer(int idPlayer, Socket socket, boolean isHuman)
    {
        super(idPlayer, isHuman);

        // used to communicate with client
        this.client = new ClientHandler(socket);
    }


    /**
     * displays player's hand to client
     */
    @Override
    protected void displayPlayerHand()
    {
        // message to send to client
        String output =
                "Playable cards in hand:\n" +
                "    " + Color.ANSI_BLUE +
                colorsCounter.get(Color.Blue) +
                " blue cards\n" +

                "    " + Color.ANSI_YELLOW +
                colorsCounter.get(Color.Yellow) +
                " yellow cards\n" +

                "    " + Color.ANSI_PURPLE +
                colorsCounter.get(Color.Purple) +
                " purple cards\n" +

                "    " + Color.ANSI_GREEN +
                colorsCounter.get(Color.Green) +
                " green cards\n" +

                "    " + Color.ANSI_RED +
                colorsCounter.get(Color.Red) +
                " red cards\n" + Color.ANSI_RESET;

        // send it
        sendMessage(output);
    }


    /**
     * prompt card to play to client and adds it to the given map
     * @param move the hashmap to populate with the card to play
     */
    @Override
    protected void promptCard(Map<String, Object> move)
    {
        do
        {
            // prompt move to player
            sendMessage("Card to play (R, P, Y, G, B; N for none): ");

            switch (receiveMessage())
            {
                case "R":
                    // if no card of this color in hand
                    if (this.colorsCounter.get(Color.Red) <= 0)
                        sendMessage("no red cards remaining");
                    else
                        move.put("card", new Card(Color.Red));
                    break;
                case "P":
                    if (this.colorsCounter.get(Color.Purple) <= 0)
                        sendMessage("no purple cards remaining");
                    else
                        move.put("card", new Card(Color.Purple));
                    break;
                case "Y":
                    if (this.colorsCounter.get(Color.Yellow) <= 0)
                        sendMessage("no yellow cards remaining");
                    else
                        move.put("card", new Card(Color.Yellow));
                    break;
                case "G":
                    if (this.colorsCounter.get(Color.Green) <= 0)
                        sendMessage("no green cards remaining");
                    else
                        move.put("card", new Card(Color.Green));
                    break;
                case "B":
                    if (this.colorsCounter.get(Color.Blue) <= 0)
                        sendMessage("no blue cards remaining");
                    else
                        move.put("card", new Card(Color.Blue));
                    break;
                case "N":
                    move.put("card", null);
            }
        }
        while (move.get("card") == null);
    }


    /**
     * prompts floor to play the card on to client and adds it to the given map
     * @param move the hashmap to populate
     */
    @Override
    protected void promptFloor(Map<String, Object> move)
    {
        // user input
        String input;

        do
        {
            // prompt floor
            sendMessage("Floor to play the card on:");
            // get floor from user input
            input = receiveMessage();
        }
        while (!Game.isInteger(input));

        // add floor to map
        move.put("floor", Integer.parseInt(input));
    }


    /**
     * prompts position to the client and adds it to the given map
     * @param move the hashmap to populate
     */
    @Override
    protected void promptPosition(Map<String, Object> move)
    {
        // user input
        String input;

        do
        {
            // prompt position
            sendMessage("Position on the floor:");
            // get position from user input
            input = receiveMessage();
        }
        while (!Game.isInteger(input));

        // add position to map
        move.put("position", Integer.parseInt(input));
    }




    /**
     * @return string representation of the current player
     */
    @Override
    public String toString()
    {
        return "Online player; ID = " + idPlayer + "; human: " + isHuman;
    }



    /**
     * writes the given message in the output stream, then sends it
     * @param message the message to send
     */
    @Override
    public void sendMessage(String message)
    {
        client.sendMessage(message);
    }


    /**
     * asks the client to answer, then gets its input
     * @return a string containing the client's input
     */
    String receiveMessage()
    {
        // string used to ask the client to answer
        sendMessage("\\");
        return client.readString();
    }
}