package network;

import engine.game.Game;
import engine.game.Player;
import engine.game.Round;

import java.util.*;

public class OnlineGame extends Game
{
    public OnlineGame(Player[] players, int nbPlayers)
    {
        super(players, nbPlayers);
    }


    /**
     * initializes online rounds array with the correct number of players
     */
    @Override
    protected void initRoundsArray()
    {
        rounds = new OnlineRound[nbPlayers];
    }


    /**
     * instantiates, stores and plays all online rounds
     */
    @Override
    protected void createAndPlayRounds()
    {
        // loop: create and play all rounds
        for (int i = 0; i < nbPlayers; i++)
        {
            // convert to ArrayList before passing it to the online round
            rounds[i] = new OnlineRound(i,
                    new ArrayList<>(Arrays.asList(this.players)));
            // play round
            rounds[i].playRoundFromPrompt();

            // get new scores after round, and store them into the Game instance
            for (int j = 0; j < nbPlayers; j++)
                this.players[j]
                        .setScore(rounds[i].getPlayers().get(j).getScore());
        }
    }


    /**
     * sends winners list to all clients
     */
    @Override
    protected void displayWinners()
    {
        // array containing players' IDs
        int[] playersID = new int[nbPlayers];
        // array containing players' scores
        int[] scores = new int[nbPlayers];
        // array containing green cards played
        int[] greenCardsPlayed = new int[nbPlayers];

        // fill arrays
        for (int i = 0; i < nbPlayers; i++)
        {
            playersID[i] = players[i].getIdPlayer();
            scores[i] = players[i].getScore();
            greenCardsPlayed[i] = players[i].getNbGreenCardsPlayed();
        }

        // apply the same sort to all arrays
        sortWinners(playersID, scores, greenCardsPlayed);

        // display results
        StringBuilder message = new StringBuilder("results:\n");
        for (int i = 0; i < nbPlayers; i++)
            message.append("    Player ").append(playersID[i]).append(": ")
                    .append(scores[i]).append(" points; ")
                    .append(greenCardsPlayed[i]).append(" green cards played");

        // display winners to all clients
        sendToAllClients(message.toString());
    }


    /**
     * sends the given string to all connected clients
     * @param message the message to send
     */
    private void sendToAllClients(String message)
    {
        for (Player player : players)
            player.sendMessage(message);
    }
}