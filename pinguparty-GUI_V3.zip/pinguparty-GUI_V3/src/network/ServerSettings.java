package network;

abstract class ServerSettings
{
    /** port to use to connect to server */
    static final int SERVER_PORT = 4242;
}
