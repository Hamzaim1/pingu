package network;

import engine.game.Player;

import java.util.concurrent.TimeUnit;

public class Server implements Runnable
{
    /** service (thread) used to allow clients to connect */
    private Service service;

    /** clients connected to the server */
    private Player[] players;
    /** nb of players currently in the lobby, including the local player */
    private int nbPlayers;

    /** game to start */
    private OnlineGame game;



    public Server()
    {
        // 6 players max
        players = new Player[6];
        // no players connected
        nbPlayers = 0;
    }


    public Server(Player p)
    {
        // default constructor
        this();

        // first player: host
        players[0] = p;
        // one player in the lobby
        nbPlayers = 1;

        /*
        // sleep while clients are connecting, then start game
        try
        {
            TimeUnit.SECONDS.sleep(5);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        startGame();
        */
    }


    /**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     */
    @Override
    public void run()
    {
        // create service allowing clients to connect
        service = new Service(this);
        // start the service
        service.start();
    }


    /**
     * starts game
     */
    void startGame()
    {
        // stop waiting for clients to connect
        service.closeServerSocket();

        // create and start online game
        game = new OnlineGame(players, nbPlayers);
    }







    /**
     * checks if there's room in the lobby to add a client
     * @return true if a client can be added, false otherwise
     */
    boolean canAddNewClient()
    {
        return nbPlayers < 6;
    }


    int getFistAvailableSlotIndex()
    {
        // counter to iterate through players array
        int i = 0;

        // while slots not available
        while (i < 5 && players[i] != null)
            ++i;

        return i;
    }


    /**
     * add a new OnlinePlayer to the server in first available slot
     * @param p the OnlinePlayer to add
     */
    void addPlayer(OnlinePlayer p)
    {
        // get index of first available slot
        int i = getFistAvailableSlotIndex();

        // store player in first available slot
        players[i] = p;

        // update nb of clients connected
        ++nbPlayers;

        // display clients
        displayClients();
    }


    private void displayClients()
    {
        for (int i = 0; i < 6; i++)
        {
            System.out.print("Client " + i + ": ");

            if (players[i] == null)
                System.out.println("not connected");
            else
                System.out.println(players[i].toString());
        }
    }


    /**
     * sends the given string to all connected clients
     * @param message the message to send
     */
    private void sendToAllClients(String message)
    {
        for (Player player : players)
            player.sendMessage(message);
    }



     int getNbPlayers()
    {
        return nbPlayers;
    }

    public void setNbPlayers(int nbPlayers)
    {
        this.nbPlayers = nbPlayers;
    }

    public static void printDebug(String message)
    {
        System.out.println(message);
    }
}