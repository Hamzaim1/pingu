package stats;

import java.io.IOException;

public class Stats {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		try {
			serialize();
		} catch (IOException e) {
 			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		deserialize();
		
		
	}

 

	private static void serialize() throws IOException {
		// TODO Auto-generated method stub
		
 		 

		
	}
	private static void deserialize() throws IOException {
		 
		// Don't forget to close the deserializer !
		 
 	}

}
