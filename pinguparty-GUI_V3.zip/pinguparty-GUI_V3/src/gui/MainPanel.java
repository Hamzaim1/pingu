package gui;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import network.*;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MainPanel extends JPanel {


	protected MainMenu mainMenu;
	protected LocalHost localHost;
	protected Game game;
	protected NetworkHost networkHost;
	protected JoinGame joinGame;
	protected LocalProfiles localProfiles;
	protected EditProfile editProfile;
	protected StatsGUI stats;
	protected Options options;
	protected Score score;

	/** thread running the server and the game engine */
	private Thread server;
	/** client used to communicate with game engine (through a socket) */
	private Client client;

	protected Font police = new Font("Arial", Font.BOLD, 30);
	//Game related Information
	protected int nbPlayers = 2;
	protected String[] Players_tab = {"Humain 1","Humain 2","IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
	protected String[] Players_tabIA = {"IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
	protected int [] nbCartesForPlayers = new int[this.nbPlayers];

	/**
	 * This panel will be set as a content pane.
	 *  It manages the different panels for the game parts, it will allow us to go from a panel to an other.
	 *  It uses a CardLayout to manage the different panels.
	 *  By default, the content pane will show the MainMenu panel.
	 */
	public MainPanel() {
		super(new CardLayout());

		//Initializing Panels

		this.mainMenu = new MainMenu();
		//Giving a string to retrieve the correct panel
		this.add(this.mainMenu, "main"); 

		this.localHost = new LocalHost();
		this.add(this.localHost, "localGame");

		this.game = new Game();
		this.add(this.game, "game");

		this.networkHost = new NetworkHost();
		this.add(this.networkHost, "networkHost");

		this.joinGame = new JoinGame();
		this.add(this.joinGame, "joinGame");

		this.editProfile = new EditProfile();
		this.add(this.editProfile, "editProfiles");

		this.localProfiles = new LocalProfiles();
		this.add(this.localProfiles, "localProfiles");

		this.stats = new StatsGUI();
		this.add(this.stats, "stats");

		this.options = new Options();
		this.add(this.options, "options");

		this.score = new Score();
		this.add(this.score, "score");







		//two lines of code to allow to switch between the panels
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, "main"); // change the string by an existing name given to a panel (this.add section)
	}
	/**
	 * Allows us to go from a panel to an other
	 */
	protected void changePanel(String pane) {
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, pane); // change the string by an existing name given to a panel (this.add section)
	}

	protected void changeNbPlayers(ActionEvent arg0) {
		boolean diminue;
		int n = Integer.parseInt(arg0.getActionCommand());
		if(this.nbPlayers>n) diminue =true;
		else diminue = false;
		this.nbPlayers =n;
		this.nbCartesForPlayers = new int[this.nbPlayers];
		setnbCartesForPlayers();
		if(diminue ==true)  
		{  for(int i =  this.localHost.tab_combo1.size()-1; i >= this.nbPlayers;i--){

			this.localHost.tab_combo1.get(i).setEnabled(false);
		};
		}
		else for(int i = 0; i <nbPlayers;i++){

			this.localHost.tab_combo1.get(i).setEnabled(true);
		};

		//t2 = new Thread(new cartesForPlayersP4());

		//t2.start();

	}

	protected void setnbCartesForPlayers() {
		this.game.rightBottomP4.removeAll();
		this.game.topPanelP4.removeAll();

		this.game.leftTopP4.removeAll();
		this.game.leftBottomP4.removeAll();
		this.game.rightTopP4.removeAll();
		for(int i =1;i<this.game.nbPlayers;i++)
		{	for(int x =0;x<this.game.nbCartesForPlayers[i]-1;x++)
		{	this.game.cartesForOthers[i][x] = new JPanel();
		this.game.cartesForOthers[i][x].setPreferredSize(new Dimension(20,35 ));
		this.game.cartesForOthers[i][x].setBackground(Color.white);
		if(i==1)
		{



			this.game.topPanelP4.add(this.game.cartesForOthers[i][x]);
		}
		else if(i==2)
		{

			this.game.leftTopP4.add(this.game.cartesForOthers[i][x]);

		}
		else if(i==3)
		{

			this.game.leftBottomP4.add(this.game.cartesForOthers[i][x]);

		}
		else if(i==4)
		{

			this.game.rightTopP4.add(this.game.cartesForOthers[i][x]);

		}
		else if(i==5)
		{

			this.game.rightBottomP4.add(this.game.cartesForOthers[i][x]);

		}
		}

		}
		this.game.leftPanelP4.removeAll();
		this.game.leftPanelP4.setLayout(new GridLayout(2,1));
		this.game.leftPanelP4.add(this.game.leftTopP4);
		this.game.leftPanelP4.add(this.game.leftBottomP4);
		this.game.rightPanelP4.removeAll();
		this.game.rightPanelP4.setLayout(new GridLayout(2,1));
		this.game.rightPanelP4.add(this.game.rightTopP4);
		this.game.rightPanelP4.add(this.game.rightBottomP4);

	}

    public Client getClient()
    {
        return client;
    }

    public void setClient(Client client)
    {
        this.client = client;
    }

    public Thread getServer()
    {
        return server;
    }

    public void setServer(Thread server)
    {
        this.server = server;
    }
}


