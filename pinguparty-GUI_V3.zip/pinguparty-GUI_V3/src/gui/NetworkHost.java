package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.LayoutStyle.ComponentPlacement;

import gui.Fenetre.UpdateWindow;
import gui.Fenetre.cartesForPlayersP4;
import gui.Fenetre.kickListenerP3;
import gui.Fenetre.tab1RadioListenerP3;
import gui.Fenetre.tab2RadioListenerP3;
import jeux.reseau;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;

public class NetworkHost extends JPanel implements ActionListener {

	protected int nbPlayers = 2;
	protected String[] Players_tab = {"Humain 1","Humain 2","IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
	protected String[] Players_tabIA = {"IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
	protected int nbLocalPlayers =1;
	//protected boolean updateP3 = false;
	protected JPanel leftPanelP3 = new JPanel();
	protected JPanel rightPanelP3 = new JPanel();
	protected JPanel bottomPanelP3 = new JPanel();
	protected JPanel centerPanelP3 = new JPanel();
	protected JPanel topPanelP3 = new JPanel();

	protected JButton bouton_P3 = new JButton("Start");
	protected JButton bouton2_P3 = new JButton("Cancel");
	protected Font police3 = new Font("Arial", Font.BOLD, 15);
	protected ButtonGroup bgP3 = new ButtonGroup();
	protected ButtonGroup bg2P3 = new ButtonGroup();
	protected JRadioButton[] tab1RadioButtonP3 = new JRadioButton[5];
	protected JRadioButton[] tab2RadioButtonP3 = new JRadioButton[5];
	protected JComboBox[] tabComboP3 = new JComboBox[5];
	protected JPanel radioPanelP3 = new JPanel();
	protected JPanel radio2PanelP3 = new JPanel();
	protected JLabel labelRadio1P3 = new JLabel("Nombre maximal de joueurs : ");
	protected JLabel labelRadio2P3 = new JLabel("Nombre de joueurs locaux : ");
	protected JPanel[] panelSlotsP3 = new JPanel[6];
	protected JLabel[] labelSlotsP3 = new JLabel[6];
	protected JLabel[] labelIpP3 = new JLabel[5];
	protected JButton[] kickButton = new JButton[5];
	protected String testIp =" <adresse ip> ";
	protected Thread t;

	public NetworkHost() {
		this.labelRadio1P3.setForeground(Color.white);
		this.labelRadio1P3.setFont(this.police3);
		this.labelRadio2P3.setForeground(Color.white);
		this.labelRadio2P3.setFont(this.police3);

		this.radioPanelP3.add(this.labelRadio1P3);
		this.radioPanelP3.setBackground(Color.DARK_GRAY);
		this.radio2PanelP3.add(this.labelRadio2P3);
		this.radio2PanelP3.setBackground(Color.DARK_GRAY);

		for(int i=0;i<this.tab1RadioButtonP3.length;i++)
		{
			this.tab1RadioButtonP3[i] = new JRadioButton(Integer.toString(i+2));
			this.tab1RadioButtonP3[i].setForeground(Color.WHITE);
			this.tab1RadioButtonP3[i].setBackground(Color.DARK_GRAY);
			this.tab1RadioButtonP3[i].setActionCommand(Integer.toString(i+2));
			this.tab1RadioButtonP3[i].setFont(this.police3);
			this.tab1RadioButtonP3[i].addActionListener(new tab1RadioListenerP3());
			//tab1RadioButtonP3[i].addActionListener(new radioListenerP3());
			this.bgP3.add(this.tab1RadioButtonP3[i]);
			this.radioPanelP3.add(this.tab1RadioButtonP3[i]);
		}
		for(int i=0;i<this.tab2RadioButtonP3.length;i++)
		{
			this.tab2RadioButtonP3[i] = new JRadioButton(Integer.toString(i+1));
			this.tab2RadioButtonP3[i].setForeground(Color.WHITE);
			this.tab2RadioButtonP3[i].setBackground(Color.DARK_GRAY);
			this.tab2RadioButtonP3[i].setActionCommand(Integer.toString(i+1));
			this.tab2RadioButtonP3[i].setFont(this.police3);
			this.tab2RadioButtonP3[i].addActionListener(new tab2RadioListenerP3());
			this.bg2P3.add(this.tab2RadioButtonP3[i]);
			this.radio2PanelP3.add(this.tab2RadioButtonP3[i]);
			if(i>=this.nbLocalPlayers) this.tab2RadioButtonP3[i].setEnabled(false);
		}
		this.tab1RadioButtonP3[0].setSelected(true);
		this.tab2RadioButtonP3[0].setSelected(true);




		this.topPanelP3.setLayout(new GridLayout(2,1));
		this.topPanelP3.setBackground(Color.DARK_GRAY);
		this.topPanelP3.add(this.radioPanelP3);
		this.topPanelP3.add(this.radio2PanelP3);




		this.leftPanelP3.setPreferredSize(new Dimension(160, 600));
		this.leftPanelP3.setBackground(Color.DARK_GRAY);
		this.rightPanelP3.setPreferredSize(new Dimension(160, 600));
		this.rightPanelP3.setBackground(Color.DARK_GRAY);
		this.bottomPanelP3.setPreferredSize(new Dimension(800, 100));
		this.bottomPanelP3.setBackground(Color.DARK_GRAY);
		this.centerPanelP3.setBackground(Color.DARK_GRAY);

		this.bouton_P3.setName("game");
		this.bouton_P3.addActionListener(this);
		this.bouton2_P3.setName("main");
		this.bouton2_P3.addActionListener(this);


		this.bottomPanelP3.add(this.bouton_P3);
		this.bottomPanelP3.add(this.bouton2_P3);

		this.setLayout(new BorderLayout());
		this.add(this.topPanelP3, BorderLayout.NORTH);
		this.add(this.leftPanelP3, BorderLayout.WEST);
		this.add(this.rightPanelP3, BorderLayout.EAST);
		this.add(this.bottomPanelP3, BorderLayout.SOUTH);
		this.add(this.centerPanelP3,BorderLayout.CENTER);

		this.centerPanelP3.setLayout(new GridLayout(6, 1, 5,2));
		int j =0;
		for(int i =0;i< this.nbPlayers;i++)
		{	
			this.panelSlotsP3[i] = new JPanel();
			this.panelSlotsP3[i].setLayout(new GridLayout(1, 3));
			this.panelSlotsP3[i].setBackground(Color.DARK_GRAY);

			this.labelSlotsP3[i] = new JLabel("Slot "+Integer.toString(i+1)+": ");
			this.labelSlotsP3[i].setForeground(Color.white);
			this.labelSlotsP3[i].setFont(this.police3);

			this.panelSlotsP3[i].add(this.labelSlotsP3[i]);
			if(i<this.nbLocalPlayers)
			{
				if(i==0)
					this.tabComboP3[i] = new JComboBox(this.Players_tab);
				else this.tabComboP3[i] = new JComboBox(this.Players_tabIA);
				if(this.Players_tab.length >= i)this.tabComboP3[i].setSelectedIndex(i);
				this.panelSlotsP3[i].add(this.tabComboP3[i]);
			}
			else
			{
				this.labelIpP3[j] = new JLabel(this.testIp);
				this.labelIpP3[j].setForeground(Color.white);
				this.labelIpP3[j].setFont(this.police3);
				this.panelSlotsP3[i].add(this.labelIpP3[j]);

				this.kickButton[j] = new JButton("Kick");
				System.out.println(j);
				this.kickButton[j].setActionCommand(Integer.toString(j));
				this.kickButton[j].addActionListener(new kickListenerP3());
				this.panelSlotsP3[i].add(this.kickButton[j]);

				j++;
			}
			this.centerPanelP3.add(this.panelSlotsP3[i]);    
		}

	}

	public void actionPerformed(ActionEvent arg0) {
		//System.out.println(((Component) arg0.getSource()).getName());
		CardLayout cl = (CardLayout)(this.getParent().getLayout());

		/* (Component) arg0.getSource()).getName() is a way of retrieving the name 
		 * given to our JButton to switch to the panel linked to it
		 */
		cl.show(this.getParent(), ((Component) arg0.getSource()).getName()); 
	}
	
	private void updateP3(){
		// nbLocalPlayers=1;
		int j =0;
		this.centerPanelP3.removeAll();

		for(int i =0;i< this.nbPlayers;i++)
		{	
			//System.out.println("updateP3 : indice : "+i);
			//panelSlotsP3[i].removeAll();
			//panelSlotsP3[i] = null;
			this.panelSlotsP3[i] = new JPanel();//
			this.panelSlotsP3[i].setLayout(new GridLayout(1, 3));
			this.panelSlotsP3[i].setBackground(Color.DARK_GRAY);
			//System.out.println("updateP3 : indice : "+i);
			//labelSlotsP3[i].removeAll();
			this.labelSlotsP3[i] = new JLabel("Slot "+Integer.toString(i+1)+": ");
			//labelSlotsP3[i].setText("Slot "+Integer.toString(i+1)+": ");
			this.labelSlotsP3[i].setForeground(Color.white);
			this.labelSlotsP3[i].setFont(this.police3);

			this.panelSlotsP3[i].add(this.labelSlotsP3[i]);
			if(i<this.nbLocalPlayers)
			{
				//tabComboP3[i].removeAll();
				if(i==0)this.tabComboP3[i] = new JComboBox(this.Players_tab);
				else this.tabComboP3[i] = new JComboBox(this.Players_tabIA);
				if(this.Players_tab.length > i)this.tabComboP3[i].setSelectedIndex(i);//
				this.panelSlotsP3[i].add(this.tabComboP3[i]);
			}
			else
			{
				//labelIpP3[j].removeAll();
				this.labelIpP3[j] = new JLabel(this.testIp);
				this.labelIpP3[j].setForeground(Color.white);
				this.labelIpP3[j].setFont(this.police3);
				this.panelSlotsP3[i].add(this.labelIpP3[j]);
				//kickButton[j].removeAll();
				this.kickButton[j] = new JButton("Kick");
				//System.out.println(j);
				this.kickButton[j].setActionCommand(Integer.toString(j));
				this.kickButton[j].addActionListener(new kickListenerP3());
				this.panelSlotsP3[i].add(this.kickButton[j]);

				j++;
			}

			this.centerPanelP3.add(this.panelSlotsP3[i]);
			// updateP3=false;



			//}
		}
		// lc.t2 = new Thread(new cartesForPlayersP4());

		//lc.t2.start();
		//SwingUtilities.updateComponentTreeUI(NetworkHost.this);
		NetworkHost.this.invalidate();
		NetworkHost.this.validate();
		NetworkHost.this.repaint();

	}

	class tab1RadioListenerP3 implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {

			NetworkHost.this.nbPlayers =Integer.parseInt(e.getActionCommand());
			// lc.nbCartesForPlayers = new int[NetworkHost.this.nbPlayers];
			//lc.setnbCartesForPlayers();
			for(int i = 0; i <NetworkHost.this.tab2RadioButtonP3.length;i++){

				if(i<NetworkHost.this.nbPlayers-1)NetworkHost.this.tab2RadioButtonP3[i].setEnabled(true);
				else NetworkHost.this.tab2RadioButtonP3[i].setEnabled(false);


			};
			NetworkHost.this.tab2RadioButtonP3[0].setSelected(true);
			NetworkHost.this.nbLocalPlayers=1;
			NetworkHost.this.t = new Thread(new UpdateWindow());

			NetworkHost.this.t.start();
			// lc.t2 = new Thread(new cartesForPlayersP4());

			//lc.t2.start();
			//updateP3 = true;
		}
	}
	class tab2RadioListenerP3 implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			NetworkHost.this.nbLocalPlayers =Integer.parseInt(e.getActionCommand());
			//updateP3 = true;
			NetworkHost.this.t = new Thread(new UpdateWindow());

			NetworkHost.this.t.start();
			//lc.t2 = new Thread(new cartesForPlayersP4());

			//lc.t2.start();
		}
	}
	class UpdateWindow implements Runnable{

		@Override
		public void run() {

			updateP3();    

		}  

	}




	
	 class kickListenerP3 implements ActionListener{

	      @Override
		public void actionPerformed(ActionEvent event){
	      	NetworkHost.this.labelIpP3[Integer.parseInt(event.getActionCommand())].setText(" Libre ");
		        }
	    }

}
