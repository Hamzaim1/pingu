package gui;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class MainWindow extends JFrame{
	
	protected MainPanel mainPane;
	/*
	 * This is the frame that will contain our contentpane
	 */
	public MainWindow()
	{
		setTitle("Pingu Card Game");
		this.mainPane = new MainPanel();
		this.add(this.mainPane);
		this.setContentPane(this.mainPane);
		/*
		The following part will allow us to retrieve information about 
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension d = tk.getScreenSize();
		int screenH= d.height;
		int screenW = d.width;
		*/
		this.setPreferredSize(new Dimension(700, 600 ));
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
	}
		
	
	
	public static void main(String[] args)
    {
		// TODO Auto-generated method stub
		MainWindow test = new MainWindow();
		test.show();
	}

}