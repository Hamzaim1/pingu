package gui;

import javax.swing.JPanel;

public class CardGUI extends JPanel {
	
	private int floor;
	private int position;
	
	public CardGUI() {
		super();
	}
	
	
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}

}
