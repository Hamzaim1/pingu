package gui;

public class Gui {

	public static void main(String[] args) {
		Fenetre fen = new Fenetre();

	}

}
