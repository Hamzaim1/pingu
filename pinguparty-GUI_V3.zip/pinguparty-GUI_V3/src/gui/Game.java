package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JPanel;

import engine.game.Card;
import gui.Fenetre.TriangleListenerP4;
import gui.Fenetre.cartesForPlayersP4;
import gui.Fenetre.mesCartesListenerP4;

public class Game extends JPanel 
{
	protected int nbPlayers = 2;
	Color colorCarte;
	Color[]mesCartesColor= {Color.BLUE,Color.GREEN,Color.RED,Color.MAGENTA,Color.YELLOW};
	protected JPanel [] mesCartes =new JPanel [6];
	protected int [] nbCartesForPlayers = new int[this.nbPlayers];
	//protected JPanel [][] triangle =new JPanel [8][];
	//protected boolean updateP3 = false;
	protected JPanel leftPanelP4 = new JPanel();
	protected JPanel rightPanelP4 = new JPanel();
	protected JPanel bottomPanelP4 = new JPanel();
	protected JPanel centerPanelP4 = new JPanel();
	JPanel topPanelP4 = new JPanel();
	protected boolean monTour = true;
	protected boolean updateP4 = false;

	protected Component tmpCont = null;
	protected Component tmp2Cont = null;
	protected Component tmp3Cont = null;
	protected JPanel triangleCont =new JPanel();
	protected JPanel [] etageTriangle =new JPanel [8];
	protected JPanel [][] triangle =new JPanel [8][];
	protected Thread t2;

	JPanel[][] cartesForOthers = new JPanel[6][15];
	JPanel leftTopP4 = new JPanel();
	JPanel leftBottomP4 = new JPanel();
	JPanel rightTopP4 = new JPanel();
	JPanel rightBottomP4 = new JPanel();

	protected JPanel leftPanelP5 = new JPanel();
	protected JPanel rightPanelP5 = new JPanel();
	protected JPanel bottomPanelP5 = new JPanel();
	protected JPanel centerPanelP5 = new JPanel();
	protected JPanel topPanelP5 = new JPanel();

	private JPanel cardToPlay;

	public Game() 
	{
		setnbCartesForPlayers();
		for( int i = 0; i< this.etageTriangle.length; i++)
		{
			this.etageTriangle[i]= new JPanel();
			this.etageTriangle[i].setBackground(Color.DARK_GRAY);
		}
		
		for( int i = 0; i< this.triangle.length; i++)
		{
			this.triangle[i]= new JPanel [i+1];
		}
		for( int i = 0; i< this.etageTriangle.length; i++)
		{
			for( int y = 0; y<this.triangle[i].length; y++)
			{
				this.etageTriangle[i].setLayout(new FlowLayout(1, 5, 1));
				this.triangle[i][y] = new CardGUI();
				((CardGUI) this.triangle[i][y]).setPosition(y);
				((CardGUI) this.triangle[i][y]).setFloor(i);
				this.triangle[i][y].addMouseListener(new MouseAdapter()
				{
					public void mouseClicked(MouseEvent e) {
						if(checkMove(e)) {
							System.out.println("pos : " + ((CardGUI) e.getSource()).getPosition() + "floor :" + ((CardGUI) e.getSource()).getFloor());
							e.getComponent().setBackground(colorCarte);
						}
					}
				});
				this.triangle[i][y].setBackground(Color.DARK_GRAY);
				this.triangle[i][y].setPreferredSize(new Dimension(30,45 ));
				this.triangle[i][y].setBorder( BorderFactory.createLineBorder(Color.white));
				this.etageTriangle[i].add(this.triangle[i][y]);

			}

		}
		this.triangleCont.setLayout(new BoxLayout(this.triangleCont, BoxLayout.PAGE_AXIS));
		this.triangleCont.setBackground(Color.DARK_GRAY);
		for( int i = 0; i< this.etageTriangle.length; i++)
		{
			this.triangleCont.add(this.etageTriangle[i]);

		}


		for( int i = 0; i< this.mesCartesColor.length; i++)
		{	

			this.mesCartes[i]= new JPanel();
			this.mesCartes[i].addMouseListener(new MouseAdapter()
			{
				public void mouseClicked(MouseEvent e) {
					colorCarte= e.getComponent().getBackground();
					System.out.println(colorCarte);
				}
			});
			this.mesCartes[i].setBackground(this.mesCartesColor[i]);
			this.mesCartes[i].setPreferredSize(new Dimension(30,45 ));
			this.mesCartes[i].setBorder( BorderFactory.createLineBorder(Color.white));
			this.bottomPanelP4.add(this.mesCartes[i]);   
		}

		//nb cartes des autres joueurs 
		//this.t2 = new Thread(new cartesForPlayersP4());

		//this.t2.start();
		this.leftBottomP4.setBackground(Color.DARK_GRAY);
		this.leftTopP4.setBackground(Color.DARK_GRAY);
		this.rightBottomP4.setBackground(Color.DARK_GRAY);
		this.rightTopP4.setBackground(Color.DARK_GRAY);

		
		this.topPanelP4.setBackground(Color.DARK_GRAY);
		//topPanelP4.setBorder(BorderFactory.createEmptyBorder(10,20,10,10));
		// Color colorTest = topPanelP4.getBackground();
		//centerPanelP4.setBackground(topPanelP4.getBackground());
		// leftPanelP4.setSize(new Dimension(800, 100));
		//leftPanelP4.setSize(new Dimension(160, 600));
		this.leftPanelP4.setBackground(Color.DARK_GRAY);
		//rightPanelP4.setSize(new Dimension(160, 600));
		this.rightPanelP4.setBackground(Color.DARK_GRAY);
		// bottomPanelP4.setSize(new Dimension(800, 100));
		this.bottomPanelP4.setBackground(Color.DARK_GRAY);
		this.bottomPanelP4.setBorder(BorderFactory.createEmptyBorder(10,30,10,10));
		//centerPanelP4.setPreferredSize(new Dimension(600, 600));
		this.centerPanelP4.setBackground(Color.DARK_GRAY);
		this.centerPanelP4.add(this.triangleCont);

		this.setLayout(new BorderLayout());
		this.add(this.topPanelP4, BorderLayout.NORTH);
		this.add(this.leftPanelP4, BorderLayout.WEST);
		this.add(this.rightPanelP4, BorderLayout.EAST);
		this.add(this.bottomPanelP4, BorderLayout.SOUTH);
		this.add(this.centerPanelP4,BorderLayout.CENTER);
	}

	protected void setnbCartesForPlayers()
	{		int tmp =0;
	switch (this.nbPlayers) {
	case 2:  tmp= 14;
	break;
	case 3:  tmp= 12;
	break;
	case 4:  tmp= 9;
	break;
	case 5:  tmp= 7;
	break;
	case 6:  tmp= 6;
	break;
	default: break;
	}
	for(int i =0;i<this.nbCartesForPlayers.length;i++)
		this.nbCartesForPlayers[i]=tmp;

	}

	protected void updateBoard() {

	}

	protected void updateCard() {

	}

	protected void clearPanel() {

	}

	protected void toMove() {

	}
	/**
	 * Creates a move by retrieving the color we wish to play. 
	 * @param e JPanel which has been clicked so that we can modify 
	 * @return
	 */
	protected boolean checkMove(MouseEvent e) {
		Map<String, Object> move = new HashMap<>();
		Color color;
		move.put("card", colorCarte);
		move.put("floor", ((CardGUI) e.getSource()).getFloor());
		move.put("position",((CardGUI) e.getSource()).getPosition());
		
		return true;
		
	}
	protected void sendMove() {
		Map<String, Object> move = new HashMap<>();
		Color color;
		//move.put("card", new Card(color));
		// move.put("floor", Integer.parseInt(input));
		// move.put("position", Integer.parseInt(input));
	}




}