package gui;

import javax.swing.JPanel;



public class LocalProfiles extends JPanel {
	


}
