package gui;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
public class Fenetre extends JFrame{

  private CardLayout cl = new CardLayout();
  private JPanel content = new JPanel();
  //Liste des noms de nos conteneurs pour la pile de cartes
  private String[] listContent = {"CARD_1", "CARD_2", "CARD_3","CARD_4", "CARD_5", "CARD_6","CARD_7", "CARD_8", "CARD_9"};
  private int indice = 0;
 
  private JPanel card1 = new JPanel();
  private JPanel card2 = new JPanel();		
  private JPanel card3 = new JPanel();
  private JPanel card4 = new JPanel();
  private JPanel card5 = new JPanel();	
  private JPanel card6 = new JPanel();
  private JPanel card7 = new JPanel();	
  private JPanel card8 = new JPanel();
  private JPanel card9 = new JPanel();
  // ***********page 2 attributes********************************
  private int nbPlayers = 2;
  private String[] Players_tab = {"Humain 1","Humain 2","IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
  private String[] Players_tabIA = {"IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
  private ButtonGroup bg_P2 = new ButtonGroup();
  private JPanel centerPanel_P2 = new JPanel();
  private JComboBox[] tab_combo1 = new JComboBox[6];
  private JPanel choixPanel_P2 = new JPanel();
  
 // ***********page 3 attributes********************************
  private int nbLocalPlayers =1;
  //private boolean updateP3 = false;
  private JPanel leftPanelP3 = new JPanel();
  private JPanel rightPanelP3 = new JPanel();
  private JPanel bottomPanelP3 = new JPanel();
  private JPanel centerPanelP3 = new JPanel();
  private JPanel topPanelP3 = new JPanel();

  private JButton bouton_P3 = new JButton("COMMECER");
  private JButton bouton2_P3 = new JButton("ANNULER");
  private Font police3 = new Font("Arial", Font.BOLD, 15);
  private ButtonGroup bgP3 = new ButtonGroup();
  private ButtonGroup bg2P3 = new ButtonGroup();
  private JRadioButton[] tab1RadioButtonP3 = new JRadioButton[5];
  private JRadioButton[] tab2RadioButtonP3 = new JRadioButton[5];
  private JComboBox[] tabComboP3 = new JComboBox[5];
  private JPanel radioPanelP3 = new JPanel();
  private JPanel radio2PanelP3 = new JPanel();
  private JLabel labelRadio1P3 = new JLabel("Nombre maximal de joueurs : ");
  private JLabel labelRadio2P3 = new JLabel("Nombre de joueurs locaux : ");
  private JPanel[] panelSlotsP3 = new JPanel[6];
  private JLabel[] labelSlotsP3 = new JLabel[6];
  private JLabel[] labelIpP3 = new JLabel[5];
  private JButton[] kickButton = new JButton[5];
  private String testIp =" <adresse ip> ";
  private Thread t;
 // ***********************Page 4 attributes***************************************
  Color colorCarte;
  Color[]mesCartesColor= {Color.BLUE,Color.GREEN,Color.RED,Color.MAGENTA,Color.YELLOW};
  private JPanel [] mesCartes =new JPanel [6];
  private int [] nbCartesForPlayers = new int[this.nbPlayers];
  //private JPanel [][] triangle =new JPanel [8][];
  //private boolean updateP3 = false;
  private JPanel leftPanelP4 = new JPanel();
  private JPanel rightPanelP4 = new JPanel();
  private JPanel bottomPanelP4 = new JPanel();
  private JPanel centerPanelP4 = new JPanel();
  private JPanel topPanelP4 = new JPanel();
  private boolean monTour = true;
  private boolean updateP4 = false;
  
  private Component tmpCont = null;
  private Component tmp2Cont = null;
  private Component tmp3Cont = null;
  private JPanel triangleCont =new JPanel();
  private JPanel [] etageTriangle =new JPanel [8];
  private JPanel [][] triangle =new JPanel [8][];
  private Thread t2;
  
  JPanel[][] cartesForOthers = new JPanel[6][15];
  JPanel leftTopP4 = new JPanel();
	JPanel leftBottomP4 = new JPanel();
	JPanel rightTopP4 = new JPanel();
	JPanel rightBottomP4 = new JPanel();

	private JPanel leftPanelP5 = new JPanel();
	  private JPanel rightPanelP5 = new JPanel();
	  private JPanel bottomPanelP5 = new JPanel();
	  private JPanel centerPanelP5 = new JPanel();
	  private JPanel topPanelP5 = new JPanel();
  //*******************************************************************************
  public Fenetre(){
    this.setTitle("CardLayout");
    this.setSize(700, 600);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLocationRelativeTo(null);
    	
    //On crée trois conteneurs de couleur différente
    
    
    //On ajoute les cartes à la pile avec un nom pour les retrouver
    this.content.setLayout(this.cl);
    this.content.add(this.card1, this.listContent[0]);
    this.content.add(this.card2, this.listContent[1]);
    this.content.add(this.card3, this.listContent[2]);
    this.content.add(this.card4, this.listContent[3]);
    this.content.add(this.card5, this.listContent[4]);
    this.content.add(this.card6, this.listContent[5]);
    this.content.add(this.card7, this.listContent[6]);
    this.content.add(this.card8, this.listContent[7]);
    this.content.add(this.card9, this.listContent[8]);
    
    ////////////titre, boutons page 1: card 1///////////////////////////////////////////////////////////
    //Tableau stockant les éléments à afficher dans la calculatrice

   /* String[] tab_string1 = {"créer partie local", "creér partie réseau", "rejoindre partie réseau",
    		"profils locaux", "statistiques", "options", "quitter"};

    //Un bouton par élément à afficher

    JButton[] tab_button1 = new JButton[tab_string1.length];
    for(int i = 0; i < tab_string1.length; i++){
        tab_button1[i] = new JButton(tab_string1[i]);
        tab_button1[i].addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent event){
    	indice = 0;
  
        cl.show(content, listContent[indice]);
    }
		*/
    JButton bouton = new JButton("cr�er partie locale");
    //Définition de l'action du bouton2
    bouton.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Fenetre.this.indice = 1;
  
        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
      }
    });
    JButton bouton2 = new JButton("cr�er partie r�seau");
    //Définition de l'action du bouton2
    bouton2.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Fenetre.this.indice = 2;
  
        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
      }
    });
    JButton bouton3 = new JButton("rejoindre r�seau");
    //Définition de l'action du bouton2
    bouton3.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Fenetre.this.indice = 4;
  
        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
      }
    });
    JButton bouton4 = new JButton("profils locaux");
    //Définition de l'action du bouton2
    bouton4.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Fenetre.this.indice = 5;
  
        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
      }
    });
    JButton bouton5 = new JButton("Statistiques");
    //Définition de l'action du bouton2
    bouton5.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Fenetre.this.indice = 5;
  
        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
      }
    });
    JButton bouton6 = new JButton("Options");
    //Définition de l'action du bouton2
    bouton6.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Fenetre.this.indice = 0;
  
        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
      }
    });
    JButton bouton7 = new JButton("Quitter");
    //Définition de l'action du bouton2
    bouton7.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	  System.exit(0);
      }
    });
    
    
    
    JPanel boutons = new JPanel();
    boutons.setLayout(new GridLayout(7, 1,10,10));
    boutons.setPreferredSize(new Dimension(300,200));
    boutons.setBackground(Color.DARK_GRAY);
    boutons.add(bouton);
    boutons.add(bouton2);
    boutons.add(bouton3);
    boutons.add(bouton4);
    boutons.add(bouton5);
    boutons.add(bouton6);
    boutons.add(bouton7);
    

    
  //titre
    JLabel titre1 = new JLabel();
    Font police = new Font("Arial", Font.BOLD, 30);
    titre1 = new JLabel("MENU PRICIPALE");
    titre1.setFont(police);
    titre1.setForeground(Color.WHITE);
    
    
    
    
    
    
    
    // on ajoute le titre et boutons au card1
    JPanel panTitre1 = new JPanel();
    panTitre1.setPreferredSize(new Dimension(600,100));
    panTitre1.add(titre1);
    panTitre1.setBorder(BorderFactory.createEmptyBorder(25,10,10,10));
    panTitre1.setBackground(Color.DARK_GRAY);
    JPanel leftPanel = new JPanel();
    leftPanel.setPreferredSize(new Dimension(160, 600));
    leftPanel.setBackground(Color.DARK_GRAY);
    JPanel rightPanel = new JPanel();
    rightPanel.setPreferredSize(new Dimension(160, 600));
    rightPanel.setBackground(Color.DARK_GRAY);
    JPanel bottomPanel = new JPanel();
    bottomPanel.setPreferredSize(new Dimension(800, 100));
    bottomPanel.setBackground(Color.DARK_GRAY);

    
    
    this.card1.setLayout(new BorderLayout());
    this.card1.add(leftPanel, BorderLayout.WEST);
    this.card1.add(rightPanel, BorderLayout.EAST);
    this.card1.add(bottomPanel, BorderLayout.SOUTH);
    this.card1.add(panTitre1,BorderLayout.NORTH);
    this.card1.add(boutons,BorderLayout.CENTER);
    
    //***************page 2************************************************
    /*
    JComboBox combo1_P2 = new JComboBox();
    JLabel label1_P2 = new JLabel("Nombre de joueurs :  2");
    combo1_P2.setPreferredSize(new Dimension(100, 20));
    
    JComboBox combo2_P2 = new JComboBox();
    JLabel label2_P2 = new JLabel("3");
    combo2_P2.setPreferredSize(new Dimension(100, 20));
    
    JComboBox combo3_P2 = new JComboBox();
    JLabel label3_P2 = new JLabel("Nombre de joueurs :");
    combo3_P2.setPreferredSize(new Dimension(100, 20));
    
    JComboBox combo4_P2 = new JComboBox();
    JLabel label4_P2 = new JLabel("Nombre de joueurs :");
    combo4_P2.setPreferredSize(new Dimension(100, 20));
    
    JComboBox combo5_P2 = new JComboBox();
    JLabel label5_P2 = new JLabel("Nombre de joueurs :");
    combo5_P2.setPreferredSize(new Dimension(100, 20));

	  JPanel top_P2 = new JPanel();
	  top_P2.add(label1_P2);
	  top_P2.add(combo1_P2);
	  card2.setLayout(new BorderLayout());
	  card2.add(top_P2, BorderLayout.NORTH);*/
    Font police2 = new Font("Arial", Font.BOLD, 20);
    
    
    JRadioButton jr1_P2 = new JRadioButton("2");
    jr1_P2.setForeground(Color.WHITE);
    jr1_P2.setBackground(Color.DARK_GRAY);
    jr1_P2.setActionCommand("2");
    jr1_P2.setFont(police2);
    JRadioButton jr2_P2 = new JRadioButton("3");
    jr2_P2.setBackground(Color.DARK_GRAY);
    jr2_P2.setForeground(Color.WHITE);
    jr2_P2.setActionCommand("3");
    jr2_P2.setFont(police2);
    JRadioButton jr3_P2 = new JRadioButton("4");
    jr3_P2.setBackground(Color.DARK_GRAY);
    jr3_P2.setForeground(Color.WHITE);
    jr3_P2.setActionCommand("4");
    jr3_P2.setFont(police2);
    JRadioButton jr4_P2 = new JRadioButton("5");
    jr4_P2.setBackground(Color.DARK_GRAY);
    jr4_P2.setForeground(Color.WHITE);
    jr4_P2.setActionCommand("5");
    jr4_P2.setFont(police2);
    JRadioButton jr5_P2 = new JRadioButton("6");
    jr5_P2.setBackground(Color.DARK_GRAY);
    jr5_P2.setForeground(Color.WHITE);
    jr5_P2.setActionCommand("6");
    jr5_P2.setFont(police2);
    
    jr1_P2.setSelected(true);
    jr1_P2.addActionListener(new radio_P2Listener());
    jr2_P2.addActionListener(new radio_P2Listener());
    jr3_P2.addActionListener(new radio_P2Listener());
    jr4_P2.addActionListener(new radio_P2Listener());
    jr5_P2.addActionListener(new radio_P2Listener());
    
    
    
    this.bg_P2.add(jr1_P2);
    this.bg_P2.add(jr2_P2);
    this.bg_P2.add(jr3_P2);
    this.bg_P2.add(jr4_P2);
    this.bg_P2.add(jr5_P2);
    JLabel label1_P2 = new JLabel("Nombre de joueurs :    ");
    label1_P2.setForeground(Color.white);
    label1_P2.setFont(police2);
    
    JPanel top_P2 = new JPanel();
    top_P2.setBackground(Color.DARK_GRAY);
	  top_P2.add(label1_P2);
	  top_P2.add(jr1_P2);
	  top_P2.add(jr2_P2);
	  top_P2.add(jr3_P2);
	  top_P2.add(jr4_P2);
	  top_P2.add(jr5_P2);

	  
	  JPanel leftPanel_P2 = new JPanel();
	    leftPanel_P2.setPreferredSize(new Dimension(160, 600));
	    leftPanel_P2.setBackground(Color.DARK_GRAY);
	    JPanel rightPanel_P2 = new JPanel();
	    rightPanel_P2.setPreferredSize(new Dimension(160, 600));
	    rightPanel_P2.setBackground(Color.DARK_GRAY);
	    JPanel bottomPanel_P2 = new JPanel();
	    bottomPanel_P2.setPreferredSize(new Dimension(800, 100));
	    bottomPanel_P2.setBackground(Color.DARK_GRAY);
	    JPanel centerPanel_P2 = new JPanel();
	    centerPanel_P2.setBackground(Color.DARK_GRAY);
	    JButton bouton_P2 = new JButton("COMMECER");
	    JButton bouton2_P2 = new JButton("ANNULER");
	    
	    bouton_P2.addActionListener(new ActionListener(){
      @Override
	public void actionPerformed(ActionEvent event){
    	Fenetre.this.indice = 3;
  
        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
      }
    });
	    
	    bouton2_P2.addActionListener(new ActionListener(){
	        @Override
			public void actionPerformed(ActionEvent event){
	      	Fenetre.this.indice = 0;
	    
	          Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
	        }
	      });
	    
	    
	    bottomPanel_P2.add(bouton_P2);
	    bottomPanel_P2.add(bouton2_P2);
	    
	    this.card2.setLayout(new BorderLayout());
		this.card2.add(top_P2, BorderLayout.NORTH);
	    this.card2.add(leftPanel_P2, BorderLayout.WEST);
	    this.card2.add(rightPanel_P2, BorderLayout.EAST);
	    this.card2.add(bottomPanel_P2, BorderLayout.SOUTH);
	    this.card2.add(centerPanel_P2,BorderLayout.CENTER);
	    
	    
        this.choixPanel_P2.setLayout(new GridLayout(6, 1,10,10));
        this.choixPanel_P2.setPreferredSize(new Dimension(200,70));
        this.choixPanel_P2.setBackground(Color.DARK_GRAY);
        centerPanel_P2.add(this.choixPanel_P2);
        this.choixPanel_P2.setBorder(BorderFactory.createEmptyBorder(60,10,10,10));
        
	    for(int i = 0; i < this.tab_combo1.length; i++){
	    	if(i==0)
	    	 this.tab_combo1[i] = new JComboBox(this.Players_tab);
	    	else this.tab_combo1[i] = new JComboBox(this.Players_tabIA);
	    	if(this.Players_tab.length >= i)this.tab_combo1[i].setSelectedIndex(i);
	        this.choixPanel_P2.add(this.tab_combo1[i]);
	  	  }
	    for(int i = this.tab_combo1.length-1; i >=this.nbPlayers;i--){
	    	
	    		this.tab_combo1[i].setEnabled(false);
	    };
	    this.card2.add(this.choixPanel_P2, BorderLayout.CENTER);
	  //***************page 3************************************************
	 //**********************************************************************
	    this.labelRadio1P3.setForeground(Color.white);
	    this.labelRadio1P3.setFont(this.police3);
	    this.labelRadio2P3.setForeground(Color.white);
	    this.labelRadio2P3.setFont(this.police3);
	    
	    this.radioPanelP3.add(this.labelRadio1P3);
	    this.radioPanelP3.setBackground(Color.DARK_GRAY);
	    this.radio2PanelP3.add(this.labelRadio2P3);
	    this.radio2PanelP3.setBackground(Color.DARK_GRAY);
	    
	    for(int i=0;i<this.tab1RadioButtonP3.length;i++)
	    {
	    	this.tab1RadioButtonP3[i] = new JRadioButton(Integer.toString(i+2));
	    	this.tab1RadioButtonP3[i].setForeground(Color.WHITE);
	    	this.tab1RadioButtonP3[i].setBackground(Color.DARK_GRAY);
	    	this.tab1RadioButtonP3[i].setActionCommand(Integer.toString(i+2));
	    	this.tab1RadioButtonP3[i].setFont(this.police3);
	    	this.tab1RadioButtonP3[i].addActionListener(new tab1RadioListenerP3());
	    	//tab1RadioButtonP3[i].addActionListener(new radioListenerP3());
	    	this.bgP3.add(this.tab1RadioButtonP3[i]);
	    	this.radioPanelP3.add(this.tab1RadioButtonP3[i]);
	    }
	    for(int i=0;i<this.tab2RadioButtonP3.length;i++)
	    {
	    	this.tab2RadioButtonP3[i] = new JRadioButton(Integer.toString(i+1));
	    	this.tab2RadioButtonP3[i].setForeground(Color.WHITE);
	    	this.tab2RadioButtonP3[i].setBackground(Color.DARK_GRAY);
	    	this.tab2RadioButtonP3[i].setActionCommand(Integer.toString(i+1));
	    	this.tab2RadioButtonP3[i].setFont(this.police3);
	    	this.tab2RadioButtonP3[i].addActionListener(new tab2RadioListenerP3());
	    	//tab2RadioButtonP3[i].addActionListener(new radioListenerP3());
	    	this.bg2P3.add(this.tab2RadioButtonP3[i]);
	    	this.radio2PanelP3.add(this.tab2RadioButtonP3[i]);
	    	if(i>=this.nbLocalPlayers) this.tab2RadioButtonP3[i].setEnabled(false);
	    }
	    this.tab1RadioButtonP3[0].setSelected(true);
	    this.tab2RadioButtonP3[0].setSelected(true);
	    
	    
	    
	    
	    this.topPanelP3.setLayout(new GridLayout(2,1));
	    this.topPanelP3.setBackground(Color.DARK_GRAY);
		this.topPanelP3.add(this.radioPanelP3);
		this.topPanelP3.add(this.radio2PanelP3);

		    this.leftPanelP3.setPreferredSize(new Dimension(160, 600));
		    this.leftPanelP3.setBackground(Color.DARK_GRAY);
		    this.rightPanelP3.setPreferredSize(new Dimension(160, 600));
		    this.rightPanelP3.setBackground(Color.DARK_GRAY);
		    this.bottomPanelP3.setPreferredSize(new Dimension(800, 100));
		    this.bottomPanelP3.setBackground(Color.DARK_GRAY);
		    this.centerPanelP3.setBackground(Color.DARK_GRAY);
		    
		    this.bouton_P3.addActionListener(new ActionListener(){
	      @Override
		public void actionPerformed(ActionEvent event){
	    	Fenetre.this.indice = 3;
	  
	        Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
	      }
	    });
		    
		    this.bouton2_P3.addActionListener(new ActionListener(){
		        @Override
				public void actionPerformed(ActionEvent event){
		      	Fenetre.this.indice = 0;
		    
		          Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
		        }
		      });
		    
		    
		    this.bottomPanelP3.add(this.bouton_P3);
		    this.bottomPanelP3.add(this.bouton2_P3);
		    
		    this.card3.setLayout(new BorderLayout());
			this.card3.add(this.topPanelP3, BorderLayout.NORTH);
		    this.card3.add(this.leftPanelP3, BorderLayout.WEST);
		    this.card3.add(this.rightPanelP3, BorderLayout.EAST);
		    this.card3.add(this.bottomPanelP3, BorderLayout.SOUTH);
		    this.card3.add(this.centerPanelP3,BorderLayout.CENTER);
		    
		    this.centerPanelP3.setLayout(new GridLayout(6, 1, 5,2));
		    int j =0;
		    for(int i =0;i< this.nbPlayers;i++)
		    {	
		    	this.panelSlotsP3[i] = new JPanel();
		    	this.panelSlotsP3[i].setLayout(new GridLayout(1, 3));
		    	this.panelSlotsP3[i].setBackground(Color.DARK_GRAY);
		    	
		    	this.labelSlotsP3[i] = new JLabel("Slot "+Integer.toString(i+1)+": ");
		    	this.labelSlotsP3[i].setForeground(Color.white);
			    this.labelSlotsP3[i].setFont(this.police3);
			    
			    this.panelSlotsP3[i].add(this.labelSlotsP3[i]);
			    if(i<this.nbLocalPlayers)
			    {
				    if(i==0)
				    	this.tabComboP3[i] = new JComboBox(this.Players_tab);
				    else this.tabComboP3[i] = new JComboBox(this.Players_tabIA);
			    	if(this.Players_tab.length >= i)this.tabComboP3[i].setSelectedIndex(i);
			    	this.panelSlotsP3[i].add(this.tabComboP3[i]);
			    }
			    else
			    {
			    	this.labelIpP3[j] = new JLabel(this.testIp);
			    	this.labelIpP3[j].setForeground(Color.white);
				    this.labelIpP3[j].setFont(this.police3);
				    this.panelSlotsP3[i].add(this.labelIpP3[j]);
				    
				    this.kickButton[j] = new JButton("Kick");
				    System.out.println(j);
				    this.kickButton[j].setActionCommand(Integer.toString(j));
				    this.kickButton[j].addActionListener(new kickListenerP3());
				    this.panelSlotsP3[i].add(this.kickButton[j]);
				    
				    j++;
			    }
			    this.centerPanelP3.add(this.panelSlotsP3[i]);    
		    }
		    
//******************page 4*********************************************************************
		    setnbCartesForPlayers();
		    for( int i = 0; i< this.etageTriangle.length; i++)
		    {
		    	   this.etageTriangle[i]= new JPanel();
		    	   this.etageTriangle[i].setBackground(Color.DARK_GRAY);
		    	   
		    }
		    for( int i = 0; i< this.triangle.length; i++)
		    {
		    	   this.triangle[i]= new JPanel [i+1];
		    	   
		    }
		    for( int i = 0; i< this.etageTriangle.length; i++)
		    {
		    	for( int y = 0; y<this.triangle[i].length; y++)
		    	{
		    		this.etageTriangle[i].setLayout(new FlowLayout(1, 5, 1));
		    		this.triangle[i][y] = new JPanel();
		    		this.triangle[i][y].addMouseListener(new TriangleListenerP4());
		    		this.triangle[i][y].setBackground(Color.DARK_GRAY);
		    		this.triangle[i][y].setPreferredSize(new Dimension(30,45 ));
		    		this.triangle[i][y].setBorder( BorderFactory.createLineBorder(Color.white));
		    		this.etageTriangle[i].add(this.triangle[i][y]);
		    		
		    	}
		
		    }
		    this.triangleCont.setLayout(new BoxLayout(this.triangleCont, BoxLayout.PAGE_AXIS));
		    this.triangleCont.setBackground(Color.DARK_GRAY);
		    for( int i = 0; i< this.etageTriangle.length; i++)
		    {
		    	   this.triangleCont.add(this.etageTriangle[i]);
		    	   
		    }
		    
		    
		    for( int i = 0; i< this.mesCartes.length; i++)
		    {	int colorRandom = (int)(Math.random() * 5);
		    	this.mesCartes[i]= new JPanel();
		    	this.mesCartes[i].addMouseListener(new mesCartesListenerP4());
		    	this.mesCartes[i].setBackground(this.mesCartesColor[colorRandom]);
		    	this.mesCartes[i].setPreferredSize(new Dimension(30,45 ));
		    	this.mesCartes[i].setBorder( BorderFactory.createLineBorder(Color.white));
		    	this.bottomPanelP4.add(this.mesCartes[i]);   
		    }
		    
		    //nb cartes des autres joueurs 
		    this.t2 = new Thread(new cartesForPlayersP4());

  	      this.t2.start();
	    	this.leftBottomP4.setBackground(Color.DARK_GRAY);
	    	this.leftTopP4.setBackground(Color.DARK_GRAY);
	    	this.rightBottomP4.setBackground(Color.DARK_GRAY);
	    	this.rightTopP4.setBackground(Color.DARK_GRAY);
	    	
	   	    this.topPanelP4.setBackground(Color.DARK_GRAY);
	   	 //topPanelP4.setBorder(BorderFactory.createEmptyBorder(10,20,10,10));
	   	   // Color colorTest = topPanelP4.getBackground();
	   	    //centerPanelP4.setBackground(topPanelP4.getBackground());
	   	// leftPanelP4.setSize(new Dimension(800, 100));
   		    //leftPanelP4.setSize(new Dimension(160, 600));
   		    this.leftPanelP4.setBackground(Color.DARK_GRAY);
   		    //rightPanelP4.setSize(new Dimension(160, 600));
   		    this.rightPanelP4.setBackground(Color.DARK_GRAY);
   		   // bottomPanelP4.setSize(new Dimension(800, 100));
   		    this.bottomPanelP4.setBackground(Color.DARK_GRAY);
   		    this.bottomPanelP4.setBorder(BorderFactory.createEmptyBorder(10,30,10,10));
   		    //centerPanelP4.setPreferredSize(new Dimension(600, 600));
   		    this.centerPanelP4.setBackground(Color.DARK_GRAY);
   		 this.centerPanelP4.add(this.triangleCont);
   		    
   		    this.card4.setLayout(new BorderLayout());
			this.card4.add(this.topPanelP4, BorderLayout.NORTH);
		    this.card4.add(this.leftPanelP4, BorderLayout.WEST);
		    this.card4.add(this.rightPanelP4, BorderLayout.EAST);
		    this.card4.add(this.bottomPanelP4, BorderLayout.SOUTH);
		    this.card4.add(this.centerPanelP4,BorderLayout.CENTER);
//*******************************page5*******************************************************
		    Object[][] data = {

			  	      {"Cysboy", "110"},

			  	      {"BZHHydde", "90"},

			  	      {"IamBow", "70"},

			  	      {"FunMan", "62"}

			  	    };
		    	
			  JLabel titreP5 = new JLabel("Score de fin de partie");
			  titreP5.setFont(police);
			  titreP5.setForeground(Color.white);
			      //Les titres des colonnes

			      String  title[] = {"Pseudo", "Score"};

			      JTable tableau = new JTable(data, title);

			      //Nous ajoutons notre tableau à notre contentPane dans un scroll

			      //Sinon les titres des colonnes ne s'afficheront pas !
			      //card5.add(titreP5):
			      JButton boutonP5 = new JButton("OK");
			      boutonP5.addActionListener(new ActionListener(){
				        @Override
						public void actionPerformed(ActionEvent event){
				      	Fenetre.this.indice = 0;
				    
				          Fenetre.this.cl.show(Fenetre.this.content, Fenetre.this.listContent[Fenetre.this.indice]);
				        }
				      });
			      this.bottomPanelP5.add(boutonP5);
			      this.card6.setLayout(new BorderLayout());
			      this.centerPanelP5.add(new JScrollPane(tableau),BorderLayout.CENTER);
			      this.topPanelP5.add(titreP5);
			      this.card6.setBackground(Color.DARK_GRAY);
			      
			      this.topPanelP5.setBackground(Color.DARK_GRAY);
			     	 //topPanelP4.setBorder(BorderFactory.createEmptyBorder(10,20,10,10));
			     	   // Color colorTest = topPanelP4.getBackground();
			     	    //centerPanelP4.setBackground(topPanelP4.getBackground());
			     	// leftPanelP4.setSize(new Dimension(800, 100));
			  		    //leftPanelP4.setSize(new Dimension(160, 600));
			  		    this.leftPanelP5.setBackground(Color.DARK_GRAY);
			  		    //rightPanelP4.setSize(new Dimension(160, 600));
			  		    this.rightPanelP5.setBackground(Color.DARK_GRAY);
			  		   // bottomPanelP4.setSize(new Dimension(800, 100));
			  		    this.bottomPanelP5.setBackground(Color.DARK_GRAY);
			  		    //bottomPanelP5.setBorder(BorderFactory.createEmptyBorder(10,30,10,10));
			  		    //centerPanelP4.setPreferredSize(new Dimension(600, 600));
			  		    this.centerPanelP5.setBackground(Color.DARK_GRAY);
			  		 //centerPanelP5.add(triangleCont);
			  		    
			  		this.card6.setLayout(new BorderLayout());
			  		  this.card6.add(this.topPanelP5, BorderLayout.NORTH);
			  		this.card6.add(this.leftPanelP5, BorderLayout.WEST);
			  	  this.card6.add(this.rightPanelP5, BorderLayout.EAST);
			  	  this.card6.add(this.bottomPanelP5, BorderLayout.SOUTH);
			  	  this.card6.add(this.centerPanelP5,BorderLayout.CENTER);
	//*********************************************************************************************	    
    this.getContentPane().add(this.content);
    this.setVisible(true);
  }	
  
  class cartesForPlayersP4 implements Runnable{

	    @Override
		public void run() {
	    	Fenetre.this.rightBottomP4.removeAll();
	    	Fenetre.this.topPanelP4.removeAll();
	    	
	    	Fenetre.this.leftTopP4.removeAll();
	    	Fenetre.this.leftBottomP4.removeAll();
	    	Fenetre.this.rightTopP4.removeAll();
	    	for(int i =1;i<Fenetre.this.nbPlayers;i++)
		    {	for(int x =0;x<Fenetre.this.nbCartesForPlayers[i]-1;x++)
		    	{	Fenetre.this.cartesForOthers[i][x] = new JPanel();
		    	Fenetre.this.cartesForOthers[i][x].setPreferredSize(new Dimension(20,35 ));
		    	Fenetre.this.cartesForOthers[i][x].setBackground(Color.white);
		    		if(i==1)
		    		{	
			    	Fenetre.this.topPanelP4.add(Fenetre.this.cartesForOthers[i][x]);
		    		}
		    		else if(i==2)
		    		{
		    			
			    	Fenetre.this.leftTopP4.add(Fenetre.this.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==3)
		    		{
		    			
		    			Fenetre.this.leftBottomP4.add(Fenetre.this.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==4)
		    		{
		    			
		    			Fenetre.this.rightTopP4.add(Fenetre.this.cartesForOthers[i][x]);
			    	
		    		}
		    		else if(i==5)
		    		{
		    			
		    			Fenetre.this.rightBottomP4.add(Fenetre.this.cartesForOthers[i][x]);
			    	
		    		}
		    	}
		    	
		    }
	    	Fenetre.this.leftPanelP4.removeAll();
		    Fenetre.this.leftPanelP4.setLayout(new GridLayout(2,1));
		    Fenetre.this.leftPanelP4.add(Fenetre.this.leftTopP4);
	    	Fenetre.this.leftPanelP4.add(Fenetre.this.leftBottomP4);
	    	Fenetre.this.rightPanelP4.removeAll();
	    	Fenetre.this.rightPanelP4.setLayout(new GridLayout(2,1));
		    Fenetre.this.rightPanelP4.add(Fenetre.this.rightTopP4);
	    	Fenetre.this.rightPanelP4.add(Fenetre.this.rightBottomP4);

	    }
	}
	
	
  class UpdateCarteP4 implements Runnable{

	    @Override
		public void run() {

	    	Fenetre.this.bottomPanelP4.remove(Fenetre.this.tmpCont);    
	    	Fenetre.this.invalidate();
		    Fenetre.this.validate();
		    Fenetre.this.repaint();

	    }
	}
  class UpdateSizeBigP4 implements Runnable{

    @Override
	public void run() {

    	((JPanel) Fenetre.this.tmp2Cont).setBorder( BorderFactory.createLineBorder(Color.red));    
    	Fenetre.this.invalidate();
	    Fenetre.this.validate();
	    Fenetre.this.repaint();
    }  
  }
class UpdateSizeSmallP4 implements Runnable{

    @Override
	public void run() {

    	((JPanel) Fenetre.this.tmp3Cont).setBorder( BorderFactory.createLineBorder(Color.white));    
    	Fenetre.this.invalidate();
	    Fenetre.this.validate();
	    Fenetre.this.repaint();

    }  

  }
  class TriangleListenerP4 implements MouseListener{
      @Override
	public void mouseClicked(MouseEvent e) {
    	  if(Fenetre.this.updateP4)
    	  {
    		  e.getComponent().setBackground(Fenetre.this.colorCarte);
    		  //bottomPanelP4.remove(tmpCont);
    		  //tmpCont.setBackground(Color.DARK_GRAY);
    		  Fenetre.this.updateP4=false;
    		  Fenetre.this.t = new Thread(new UpdateCarteP4());

    	      Fenetre.this.t.start();
    		 // Fenetre.this.invalidate();
    		   // Fenetre.this.validate();
    		    //Fenetre.this.repaint();
    	  }
      }
	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		Fenetre.this.tmp2Cont=e.getComponent();
		Fenetre.this.t2 = new Thread(new UpdateSizeBigP4());

	      Fenetre.this.t2.start();
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		Fenetre.this.tmp3Cont=e.getComponent();
		Fenetre.this.t2 = new Thread(new UpdateSizeSmallP4());

	      Fenetre.this.t2.start();
	}
	
	
}

  class mesCartesListenerP4 implements MouseListener{
      @Override
	public void mouseClicked(MouseEvent e) {
    	  Fenetre.this.colorCarte= e.getComponent().getBackground();
    	  Fenetre.this.tmpCont=e.getComponent();
    	  Fenetre.this.updateP4=true;
      }

	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		Fenetre.this.tmp2Cont=e.getComponent();
		Fenetre.this.t2 = new Thread(new UpdateSizeBigP4());

	      Fenetre.this.t2.start();
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		Fenetre.this.tmp3Cont=e.getComponent();
		Fenetre.this.t2 = new Thread(new UpdateSizeSmallP4());

	      Fenetre.this.t2.start();
	}
}
  
  class UpdateWindow implements Runnable{

	    @Override
		public void run() {

	    	updateP3();    
	    }  
	  }
  
  private void updateP3(){
	 // nbLocalPlayers=1;
	  int j =0;
	  this.centerPanelP3.removeAll();
	  
	    for(int i =0;i< this.nbPlayers;i++)
	    {	
	    	//System.out.println("updateP3 : indice : "+i);
	    	//panelSlotsP3[i].removeAll();
	    	//panelSlotsP3[i] = null;
	    	this.panelSlotsP3[i] = new JPanel();//
	    	this.panelSlotsP3[i].setLayout(new GridLayout(1, 3));
	    	this.panelSlotsP3[i].setBackground(Color.DARK_GRAY);
	    	//System.out.println("updateP3 : indice : "+i);
	    	//labelSlotsP3[i].removeAll();
	    	this.labelSlotsP3[i] = new JLabel("Slot "+Integer.toString(i+1)+": ");
	    	//labelSlotsP3[i].setText("Slot "+Integer.toString(i+1)+": ");
	    	this.labelSlotsP3[i].setForeground(Color.white);
		    this.labelSlotsP3[i].setFont(this.police3);
		    
		    this.panelSlotsP3[i].add(this.labelSlotsP3[i]);
		    if(i<this.nbLocalPlayers)
		    {
		    	//tabComboP3[i].removeAll();
			    if(i==0)this.tabComboP3[i] = new JComboBox(this.Players_tab);
			    else this.tabComboP3[i] = new JComboBox(this.Players_tabIA);
		    	if(this.Players_tab.length > i)this.tabComboP3[i].setSelectedIndex(i);//
		    	this.panelSlotsP3[i].add(this.tabComboP3[i]);
		    }
		    else
		    {
		    	//labelIpP3[j].removeAll();
		    	this.labelIpP3[j] = new JLabel(this.testIp);
		    	this.labelIpP3[j].setForeground(Color.white);
			    this.labelIpP3[j].setFont(this.police3);
			    this.panelSlotsP3[i].add(this.labelIpP3[j]);
			    //kickButton[j].removeAll();
			    this.kickButton[j] = new JButton("Kick");
			    //System.out.println(j);
			    this.kickButton[j].setActionCommand(Integer.toString(j));
			    this.kickButton[j].addActionListener(new kickListenerP3());
			    this.panelSlotsP3[i].add(this.kickButton[j]);
			    
			    j++;
		    }
		    
		    this.centerPanelP3.add(this.panelSlotsP3[i]);
		   // updateP3=false;
		    
		    
		    
	    //}
	 }
	    this.t2 = new Thread(new cartesForPlayersP4());

	      this.t2.start();
	 //SwingUtilities.updateComponentTreeUI(Fenetre.this);
	    Fenetre.this.invalidate();
	    Fenetre.this.validate();
	    Fenetre.this.repaint();
	  
  }
  private void setnbCartesForPlayers()
  {		int tmp =0;
	  switch (this.nbPlayers) {
      case 2:  tmp= 14;
               break;
      case 3:  tmp= 12;
               break;
      case 4:  tmp= 9;
               break;
      case 5:  tmp= 7;
      			break;
      case 6:  tmp= 6;
      			break;
      default: break;
	  }
	  for(int i =0;i<this.nbCartesForPlayers.length;i++)
		  this.nbCartesForPlayers[i]=tmp;
               
  }
  
  class tab1RadioListenerP3 implements ActionListener{
      @Override
	public void actionPerformed(ActionEvent e) {
 
    	  Fenetre.this.nbPlayers =Integer.parseInt(e.getActionCommand());
    	  Fenetre.this.nbCartesForPlayers = new int[Fenetre.this.nbPlayers];
    	  setnbCartesForPlayers();
    	for(int i = 0; i <Fenetre.this.tab2RadioButtonP3.length;i++){
	  		
	    		if(i<Fenetre.this.nbPlayers-1)Fenetre.this.tab2RadioButtonP3[i].setEnabled(true);
	    		else Fenetre.this.tab2RadioButtonP3[i].setEnabled(false);
	    		
	    		
	    };
	    Fenetre.this.tab2RadioButtonP3[0].setSelected(true);
	    Fenetre.this.nbLocalPlayers=1;
	    Fenetre.this.t = new Thread(new UpdateWindow());

	      Fenetre.this.t.start();
	      Fenetre.this.t2 = new Thread(new cartesForPlayersP4());

  	      Fenetre.this.t2.start();
	    //updateP3 = true;
      }
    }
  class tab2RadioListenerP3 implements ActionListener{
      @Override
	public void actionPerformed(ActionEvent e) {
    	  Fenetre.this.nbLocalPlayers =Integer.parseInt(e.getActionCommand());
    	  //updateP3 = true;
    	  Fenetre.this.t = new Thread(new UpdateWindow());

          Fenetre.this.t.start();
          Fenetre.this.t2 = new Thread(new cartesForPlayersP4());

  	      Fenetre.this.t2.start();
      }
}
  
  
  class kickListenerP3 implements ActionListener{
      @Override
	public void actionPerformed(ActionEvent event){
      	Fenetre.this.labelIpP3[Integer.parseInt(event.getActionCommand())].setText(" Libre ");
	        }
}
  class radio_P2Listener implements ActionListener{
      @Override
	public void actionPerformed(ActionEvent e) {
    	  boolean diminue;
    	  int n = Integer.parseInt(e.getActionCommand());
    	  if(Fenetre.this.nbPlayers>n) diminue =true;
    	  else diminue = false;
    	  Fenetre.this.nbPlayers =n;
    	  Fenetre.this.nbCartesForPlayers = new int[Fenetre.this.nbPlayers];
    	  setnbCartesForPlayers();
    	if(diminue ==true)  
    	{  for(int i = Fenetre.this.tab_combo1.length-1; i >=Fenetre.this.nbPlayers;i--){
	
	  	    		Fenetre.this.tab_combo1[i].setEnabled(false);
	  	    };
    	}
	  	else for(int i = 0; i <Fenetre.this.nbPlayers;i++){
	  		
	    		Fenetre.this.tab_combo1[i].setEnabled(true);
	    };
  	  
	    Fenetre.this.t2 = new Thread(new cartesForPlayersP4());

	      Fenetre.this.t2.start();
  	  
      }
    }

}