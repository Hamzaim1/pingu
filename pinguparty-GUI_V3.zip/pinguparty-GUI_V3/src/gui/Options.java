package gui;

import java.awt.CardLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Options extends JPanel implements ActionListener {

	protected JLabel title;
	protected JButton quitBut;

	
	public Options(){
		this.addElements();
	}
	
	protected void addElements(){
		this.title = new JLabel("Options");
		this.add(this.title);
		this.createButtons();
	}

	protected void createButtons(){
		this.quitBut = new JButton("Quit");
		this.quitBut.setName("main");
		this.quitBut.addActionListener(this);
		this.add(this.quitBut);
		
	}
	@Override
	public void actionPerformed(ActionEvent e){
		//System.out.println(((Component) arg0.getSource()).getName());
		CardLayout cl = (CardLayout)(this.getParent().getLayout());

		/* (Component) arg0.getSource()).getName() is a way of retrieving the name 
		 * given to our JButton to switch to the panel linked to it
		 */
		cl.show(this.getParent(), ((Component) e.getSource()).getName()); 
	}
}
