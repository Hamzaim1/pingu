package gui;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



public class StatsGUI extends JPanel {
	
	private JTable playerList;
	private Object[] columnNames;
	private Object[][] elementList;
	private DefaultTableModel tableModel;
	
	
	public StatsGUI() {
		Object[] columns = {"Id", "Nickname", "Email", "Is Human", "Difficulty", "Elo", "Wins", "Losses", "Draws", "Games Playes", "Win Rate", "Average Score", "Total Score", "Average Game Length", "Time Spent"};
		this.tableModel = new DefaultTableModel(columns,0){

		    @Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		//this.retrieveData();
		this.playerList = new JTable(this.tableModel);
		
		JScrollPane scrollPane = new JScrollPane( this.playerList );
		this.add(scrollPane);
	}
	//Not usable without stats
	private void retrieveData() {
		//Implementing in profiles v2.0
	}
	
}
