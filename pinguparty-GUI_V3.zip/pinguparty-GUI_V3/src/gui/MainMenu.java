package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MainMenu extends JPanel implements ActionListener {

	protected JLabel title;
	protected JButton localHost;
	protected JButton networkHost;
	protected JButton joinGame;
	protected JButton localProfiles;
	protected JButton stats;
	protected JButton quit;
	protected JButton options;

	public MainMenu() {
		this.localHost = new JButton("Create Local Game");
		this.localHost.setName("localGame");
		//Définition de l'action du bouton2
		this.localHost.addActionListener(this);

		this.networkHost = new JButton("Create Online Game");
		this.networkHost.setName("networkHost");
		//Définition de l'action du bouton2
		this.networkHost.addActionListener(this);
		
		this.joinGame= new JButton("Join Online Game");
		this.joinGame.setName("joinGame");
		//Définition de l'action du bouton2
		this.joinGame.addActionListener(this);
		
		this.localProfiles = new JButton("Local Profiles");
		this.localProfiles.setName("localProfiles");
		//Définition de l'action du bouton2
		this.localProfiles.addActionListener(this);
		
		this.stats = new JButton("Statistics");
		this.stats.setName("stats");
		//Définition de l'action du bouton2
		this.stats.addActionListener(this);
		
		this.options = new JButton("Score");
		this.options.setName("score");
		//Définition de l'action du bouton2
		this.options.addActionListener(this);
		
		this.quit = new JButton("Quit");
		this.quit.setName("quit");
		//Définition de l'action du bouton2
		this.quit.addActionListener(this);



		JPanel boutons = new JPanel();
		boutons.setLayout(new GridLayout(7, 1,10,10));
		boutons.setPreferredSize(new Dimension(300,200));
		boutons.setBackground(Color.DARK_GRAY);
		boutons.add(this.localHost);
		boutons.add(this.networkHost);
		boutons.add(this.joinGame);
		boutons.add(this.localProfiles);
		boutons.add(this.stats);
		boutons.add(this.options);
		boutons.add(this.quit);



		//titre
		this.title = new JLabel();
		Font police = new Font("Arial", Font.BOLD, 30);
		this.title = new JLabel("Main Menu");
		this.title.setFont(police);
		this.title.setForeground(Color.WHITE);







		// on ajoute le titre et boutons au card1
		JPanel panTitre1 = new JPanel();
		panTitre1.setPreferredSize(new Dimension(600,100));
		panTitre1.add(this.title);
		panTitre1.setBorder(BorderFactory.createEmptyBorder(25,10,10,10));
		panTitre1.setBackground(Color.DARK_GRAY);
		JPanel leftPanel = new JPanel();
		leftPanel.setPreferredSize(new Dimension(160, 600));
		leftPanel.setBackground(Color.DARK_GRAY);
		JPanel rightPanel = new JPanel();
		rightPanel.setPreferredSize(new Dimension(160, 600));
		rightPanel.setBackground(Color.DARK_GRAY);
		JPanel bottomPanel = new JPanel();
		bottomPanel.setPreferredSize(new Dimension(800, 100));
		bottomPanel.setBackground(Color.DARK_GRAY);



		this.setLayout(new BorderLayout());
		this.add(leftPanel, BorderLayout.WEST);
		this.add(rightPanel, BorderLayout.EAST);
		this.add(bottomPanel, BorderLayout.SOUTH);
		this.add(panTitre1,BorderLayout.NORTH);
		this.add(boutons,BorderLayout.CENTER);
	}

	public void actionPerformed(ActionEvent arg0) {
		System.out.println(((Component) arg0.getSource()).getName());
		CardLayout cl = (CardLayout)(this.getParent().getLayout());

		/* (Component) arg0.getSource()).getName() is a way of retrieving the name 
		 * given to our JButton to switch to the panel linked to it
		 */
		cl.show(this.getParent(), ((Component) arg0.getSource()).getName()); 
	}
}
