package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import gui.Fenetre.cartesForPlayersP4;

public class LocalHost extends JPanel implements ActionListener  {


	protected ButtonGroup bg_P2 = new ButtonGroup();
	protected JPanel centerPanel_P2 = new JPanel();

	protected ArrayList<JComboBox> tab_combo1 ;
	protected JPanel choixPanel_P2 = new JPanel();
	private String[] Players_tab = {"Humain 1","Humain 2","IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};
	private String[] Players_tabIA = {"IA 1","IA 2","IA 3","IA 4","IA 5","IA 6"};

	public LocalHost() {
		Font police2 = new Font("Arial", Font.BOLD, 20);


		JRadioButton jr1_P2 = new JRadioButton("2");
		jr1_P2.setForeground(Color.WHITE);
		jr1_P2.setBackground(Color.DARK_GRAY);
		jr1_P2.setActionCommand("2");
		jr1_P2.setFont(police2);
		JRadioButton jr2_P2 = new JRadioButton("3");
		jr2_P2.setBackground(Color.DARK_GRAY);
		jr2_P2.setForeground(Color.WHITE);
		jr2_P2.setActionCommand("3");
		jr2_P2.setFont(police2);
		JRadioButton jr3_P2 = new JRadioButton("4");
		jr3_P2.setBackground(Color.DARK_GRAY);
		jr3_P2.setForeground(Color.WHITE);
		jr3_P2.setActionCommand("4");
		jr3_P2.setFont(police2);
		JRadioButton jr4_P2 = new JRadioButton("5");
		jr4_P2.setBackground(Color.DARK_GRAY);
		jr4_P2.setForeground(Color.WHITE);
		jr4_P2.setActionCommand("5");
		jr4_P2.setFont(police2);
		JRadioButton jr5_P2 = new JRadioButton("6");
		jr5_P2.setBackground(Color.DARK_GRAY);
		jr5_P2.setForeground(Color.WHITE);
		jr5_P2.setActionCommand("6");
		jr5_P2.setFont(police2);

		jr1_P2.setSelected(true);
		
		jr1_P2.addActionListener(this);
		jr2_P2.addActionListener(this);
		jr3_P2.addActionListener(this);
		jr4_P2.addActionListener(this);
		jr5_P2.addActionListener(this);
		 


		this.bg_P2.add(jr1_P2);
		this.bg_P2.add(jr2_P2);
		this.bg_P2.add(jr3_P2);
		this.bg_P2.add(jr4_P2);
		this.bg_P2.add(jr5_P2);
		JLabel label1_P2 = new JLabel("Nombre de joueurs :    ");
		label1_P2.setForeground(Color.white);
		label1_P2.setFont(police2);

		JPanel top_P2 = new JPanel();
		top_P2.setBackground(Color.DARK_GRAY);
		top_P2.add(label1_P2);
		top_P2.add(jr1_P2);
		top_P2.add(jr2_P2);
		top_P2.add(jr3_P2);
		top_P2.add(jr4_P2);
		top_P2.add(jr5_P2);


		JPanel leftPanel_P2 = new JPanel();
		leftPanel_P2.setPreferredSize(new Dimension(160, 600));
		leftPanel_P2.setBackground(Color.DARK_GRAY);
		JPanel rightPanel_P2 = new JPanel();
		rightPanel_P2.setPreferredSize(new Dimension(160, 600));
		rightPanel_P2.setBackground(Color.DARK_GRAY);
		JPanel bottomPanel_P2 = new JPanel();
		bottomPanel_P2.setPreferredSize(new Dimension(800, 100));
		bottomPanel_P2.setBackground(Color.DARK_GRAY);
		JPanel centerPanel_P2 = new JPanel();
		centerPanel_P2.setBackground(Color.DARK_GRAY);
		JButton bouton_P2 = new JButton("Start");
		bouton_P2.setName("game");
		JButton bouton2_P2 = new JButton("Cancel");
		bouton2_P2.setName("main");

		bouton_P2.addActionListener(this);

		bouton2_P2.addActionListener(this);


		bottomPanel_P2.add(bouton_P2);
		bottomPanel_P2.add(bouton2_P2);

		this.setLayout(new BorderLayout());
		this.add(top_P2, BorderLayout.NORTH);
		this.add(leftPanel_P2, BorderLayout.WEST);
		this.add(rightPanel_P2, BorderLayout.EAST);
		this.add(bottomPanel_P2, BorderLayout.SOUTH);
		this.add(centerPanel_P2,BorderLayout.CENTER);


		this.choixPanel_P2.setLayout(new GridLayout(6, 1,10,10));
		this.choixPanel_P2.setPreferredSize(new Dimension(200,70));
		this.choixPanel_P2.setBackground(Color.DARK_GRAY);
		centerPanel_P2.add(this.choixPanel_P2);
		this.choixPanel_P2.setBorder(BorderFactory.createEmptyBorder(60,10,10,10));

		this.tab_combo1 = new ArrayList<JComboBox>(6);
		this.tab_combo1.add(0,new JComboBox<>(this.Players_tab));
		this.choixPanel_P2.add(this.tab_combo1.get(0));
		System.out.println("size" +this.tab_combo1.size());
		for(int i = 1; i < 6; i++){

			this.tab_combo1.add(i, new JComboBox<>(this.Players_tabIA));
			this.choixPanel_P2.add(this.tab_combo1.get(i));
		}
		for(int i = 5; i >=2;i--){

			this.tab_combo1.get(i).setEnabled(false);
		};
		this.add(this.choixPanel_P2, BorderLayout.CENTER);
	}




	@Override
	public void actionPerformed(ActionEvent arg0) {

		if(arg0.getSource().getClass() == JButton.class) {
			//System.out.println(((Component) arg0.getSource()).getName());
			CardLayout cl = (CardLayout)(this.getParent().getLayout());

			/* (Component) arg0.getSource()).getName() is a way of retrieving the name 
			 * given to our JButton to switch to the panel linked to it
			 */
			cl.show(this.getParent(), ((Component) arg0.getSource()).getName()); 
		}

		if(arg0.getSource().getClass() == JRadioButton.class) {
			
			this.changeNbPlayers( arg0);
		}

	}

	public void changeNbPlayers(ActionEvent arg0) {
		boolean diminue;
		int n = Integer.parseInt(arg0.getActionCommand());
		System.out.println(n);
		if(((MainPanel) this.getParent()).nbPlayers>n) diminue =true;
		else diminue = false;
		((MainPanel) this.getParent()).nbPlayers =n;
		((MainPanel) this.getParent()).nbCartesForPlayers = new int[((MainPanel) this.getParent()).nbPlayers];
		((MainPanel) this.getParent()).setnbCartesForPlayers();
		if(diminue ==true)  
		{  for(int i = 5; i >=((MainPanel) this.getParent()).nbPlayers;i--){

			this.tab_combo1.get(i).setEnabled(false);
		};
		}
		else for(int i = 0; i <((MainPanel) this.getParent()).nbPlayers;i++){

			this.tab_combo1.get(i).setEnabled(true);
		};

		//((MainPanel) this.getParent()).t2 = new Thread(new cartesForPlayersP4());

		//((MainPanel) this.getParent()).t2.start();

	}
	




}












