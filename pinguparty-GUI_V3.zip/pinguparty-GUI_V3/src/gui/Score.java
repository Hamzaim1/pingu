package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Score extends JPanel implements ActionListener{
	protected JPanel leftPanelP5 = new JPanel();
	protected JPanel rightPanelP5 = new JPanel();
	protected JPanel bottomPanelP5 = new JPanel();
	protected JPanel centerPanelP5 = new JPanel();
	protected JPanel topPanelP5 = new JPanel();
	protected Font police = new Font("Arial", Font.BOLD, 30);

	public Score() {

		Object[][] data = {

				{"Cysboy", "110"},

				{"BZHHydde", "90"},

				{"IamBow", "70"},

				{"FunMan", "62"}

		};

		JLabel titreP5 = new JLabel("Score de fin de partie");
		titreP5.setFont(police);
		titreP5.setForeground(Color.white);
		//Les titres des colonnes

		String  title[] = {"Pseudo", "Score"};

		JTable tableau = new JTable(data, title);

		//Nous ajoutons notre tableau à notre contentPane dans un scroll

		//Sinon les titres des colonnes ne s'afficheront pas !
		//card5.add(titreP5):
		JButton boutonP5 = new JButton("OK");
		boutonP5.setName("main");
		boutonP5.addActionListener(this);
		this.bottomPanelP5.add(boutonP5);
		this.setLayout(new BorderLayout());
		this.centerPanelP5.add(new JScrollPane(tableau),BorderLayout.CENTER);
		this.topPanelP5.add(titreP5);
		this.setBackground(Color.DARK_GRAY);

		this.topPanelP5.setBackground(Color.DARK_GRAY);
		//topPanelP4.setBorder(BorderFactory.createEmptyBorder(10,20,10,10));
		// Color colorTest = topPanelP4.getBackground();
		//centerPanelP4.setBackground(topPanelP4.getBackground());
		// leftPanelP4.setSize(new Dimension(800, 100));
		//leftPanelP4.setSize(new Dimension(160, 600));
		this.leftPanelP5.setBackground(Color.DARK_GRAY);
		//rightPanelP4.setSize(new Dimension(160, 600));
		this.rightPanelP5.setBackground(Color.DARK_GRAY);
		// bottomPanelP4.setSize(new Dimension(800, 100));
		this.bottomPanelP5.setBackground(Color.DARK_GRAY);
		//bottomPanelP5.setBorder(BorderFactory.createEmptyBorder(10,30,10,10));
		//centerPanelP4.setPreferredSize(new Dimension(600, 600));
		this.centerPanelP5.setBackground(Color.DARK_GRAY);
		//centerPanelP5.add(triangleCont);

		this.setLayout(new BorderLayout());
		this.add(this.topPanelP5, BorderLayout.NORTH);
		this.add(this.leftPanelP5, BorderLayout.WEST);
		this.add(this.rightPanelP5, BorderLayout.EAST);
		this.add(this.bottomPanelP5, BorderLayout.SOUTH);
		this.add(this.centerPanelP5,BorderLayout.CENTER);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		CardLayout cl = (CardLayout)(this.getParent().getLayout());

		/* (Component) arg0.getSource()).getName() is a way of retrieving the name 
		 * given to our JButton to switch to the panel linked to it
		 */
		cl.show(this.getParent(), ((Component) e.getSource()).getName()); 
	}

}
