package gui;

import javax.swing.JPanel;

public class Stats extends JPanel {

}
