package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class EditProfile extends JPanel implements ActionListener{

	protected JLabel title;
	protected JButton quitBut;
	protected JButton confirmBut;

	protected JPanel leftPanel = new JPanel();
	protected JPanel rightPanel = new JPanel();
	protected JPanel bottomPanel = new JPanel();
	protected JPanel centerPanel = new JPanel();
	protected JPanel topPanel = new JPanel();


	public EditProfile() {
		addElements();
	}
	
	protected void addElements(){
		this.setLayout(new BorderLayout());
		this.add(this.topPanel, BorderLayout.NORTH);
		this.add(this.leftPanel, BorderLayout.WEST);
		this.add(this.rightPanel, BorderLayout.EAST);
		this.add(this.bottomPanel, BorderLayout.SOUTH);
		this.add(this.centerPanel,BorderLayout.CENTER);
		this.title = new JLabel("Edit Profile ");

		this.topPanel.add(this.title);
		this.createButtons();
		
	}

	protected void createButtons(){
		this.quitBut = new JButton("Quit");
		this.quitBut.setName("main");
		this.quitBut.addActionListener(this);
		this.bottomPanel.add(this.quitBut );

		this.confirmBut = new JButton("Join Game");

		this.centerPanel.add(this.confirmBut );
	}


	public void actionPerformed(ActionEvent e) {
		CardLayout cl = (CardLayout)(this.getParent().getLayout());

		/* (Component) arg0.getSource()).getName() is a way of retrieving the name 
		 * given to our JButton to switch to the panel linked to it
		 */
		cl.show(this.getParent(), ((Component) e.getSource()).getName()); 
	}

}

